/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import static tp2_poo.FenetrePartie.numCaseCourante;

/**
 *
 * @author mohammed_bey
 */
public class CaseParcours extends CaseJeu {

    public CaseParcours(final InfoJeu info, final DiceGame de, final int num) {
        super();
//        this.setIcon(new ImageIcon("help.png"));
        setText(Integer.toString(num));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                if (CaseParcours.this.isEnabled()) {
                    try {
                        if (num != numCaseCourante) {
                            throw new DeplacementException();
                        }
                        JOptionPane.showMessageDialog(null, "Veuillez relancer le dé ");
                        de.bouton.setEnabled(true);
                    } catch (DeplacementException de) {
                    }
                }
            }
        });
    }

    //retourner le type de la case
    @Override
    public String toString() {
        return "7";
    }
}
