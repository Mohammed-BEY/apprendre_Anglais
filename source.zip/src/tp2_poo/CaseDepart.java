/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.ImageIcon;
import javax.swing.JOptionPane;
import static tp2_poo.FenetrePartie.numCaseCourante;

/**
 *
 * @author mohammed_bey
 */
public class CaseDepart extends CaseJeu {

    public CaseDepart(final InfoJeu info, final DiceGame de) {
        super();
//        this.setIcon(new ImageIcon("email.png"));
        setText(Integer.toString(1));
        setBackground(Color.YELLOW);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                if (CaseDepart.this.isEnabled()) {//verifier si la partie n'est pas en pause
                    try {
                        if (numCaseCourante != 1) {
                            throw new DeplacementException();
                        }
                        setIcon(new ImageIcon("oiseau.18206.gif"));
                        setPreferredSize(new Dimension(20, 20));
                        JOptionPane.showMessageDialog(null, "Veuillez lancer le dé ");
                        de.bouton.setEnabled(true);
                    } catch (DeplacementException de) {
                        de.getMessage();
                    }
                }
            }
        });
    }

    //retourner le type de la case
    @Override
    public String toString() {
        return "0";
    }
}
