/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

/**
 *
 * @author mohammed_bey
 */
public class FenetreNomUtilisateur extends JFrame {

    JTextField userNamme;
    JButton bValider;

    public FenetreNomUtilisateur() {
        //rendre l'arriere plan de la fenetre 'blanche'
        getContentPane().setBackground(Color.WHITE);
        setTitle("nom d'utilisateur");
        setSize(400, 200);
        setResizable(false);
        //centrer la fenetre
        this.setLocationRelativeTo(null);
        //enlever les layouts de la fenetre
        getContentPane().setLayout(null);
        //instancier le champ de saisie et interdire d'introduire les caracteres speciaux
        userNamme = new JTextField() {//interdire d'inroduire les caractéres spéciaux dans le TextField (champ de saise de l'information)
            public void replaceText(int start, int end, String text) {
                if (!text.matches("[ \\[\\]!\"#$%&'()*+/:;<=>?@\\^`{|}~]")) {
                }
            }

            @Override
            public void replaceSelection(String text) {
                if (!text.matches("[ \\[\\]!\"#$%&'()*+/:;<=>?@\\^`{|}~]")) {
                    super.replaceSelection(text);
                }
            }
        };
        userNamme.setSelectedTextColor(Color.red);
        //instancier les boutons
        bValider = new JButton("valider");
        //Creer les labels
        JLabel labMess = new JLabel("Veuillez introduire le nom d'utilisateur :"), labImage = new JLabel(new ImageIcon("imageApp.jpg"));

        //ajouter les composants au conteneur
        add(labMess);
        add(userNamme);
        add(bValider);
        add(labImage);
        //positionner les comopsants dans le conteneur
        labMess.setBounds(10, 10, 300, 33);
        userNamme.setBounds(10, 50, 200, 33);
        bValider.setBounds(50, 120, 120, 33);
        labImage.setBounds(250, 20, 128, 128);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//Terminer le processus lorsqu'on clique sur "Fermer"
        show();
    }
}
