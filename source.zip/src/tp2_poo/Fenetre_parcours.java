package tp2_poo;

import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JFrame;

public class Fenetre_parcours extends JDialog {

    String chemin;
    int resultat;

    public Fenetre_parcours(boolean operation) {//operation=Vrai : operation d'ouverture
        JFileChooser fParcours;
        fParcours = new JFileChooser();
        if (operation) {
            setTitle("chargement d'une partie");
            resultat = fParcours.showOpenDialog(fParcours);
            if (fParcours.getSelectedFile() != null) {
                chemin = fParcours.getSelectedFile().getPath();
            }
        } else {
            setTitle("sauvegarde d'une partie");
            resultat = fParcours.showSaveDialog(fParcours);
            if (fParcours.getSelectedFile() != null) {
                chemin = fParcours.getSelectedFile().getPath();
            }
        }

        setSize(600, 400);
        setResizable(false);
        setVisible(true);
        setLocationRelativeTo(null);//centrer la fenetre
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }
}
