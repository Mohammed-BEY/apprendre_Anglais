/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.JLabel;

/**
 *
 * @author mohammed_bey
 */
public final class LabelMotAnglais extends JLabel {

    String mot;

    public LabelMotAnglais(String mot) {
        setText(mot);
        setMot(mot);
    }

    @Override
    public void paintComponent(Graphics g) {
        Graphics2D g2d = (Graphics2D) g;
        GradientPaint gp = new GradientPaint(0, 0, Color.white, 0, 20, Color.gray, true);
        g2d.setPaint(gp);
        g2d.setColor(Color.RED);
        g2d.drawString(this.mot, 0, (this.getHeight() / 2) + 5);
        //Définition d'une police d'écriture
        //On applique celle-ci aux JLabel
        setFont(new Font("Times New Roman", Font.BOLD, 16));
        //On change la couleur de police
    }

    public void setMot(String name) {
        this.mot = name;
    }
}
