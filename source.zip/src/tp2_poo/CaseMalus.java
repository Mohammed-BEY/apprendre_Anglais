/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import static tp2_poo.FenetrePartie.numCaseCourante;

/**
 *
 * @author mohammed_bey
 */
public class CaseMalus extends CaseJeu {

    public CaseMalus(final InfoJeu info, DiceGame de, final JoueurTP joueur, final int num) {
        super();
//        this.setIcon(new ImageIcon("record.png"));
        setBackground(Color.RED);
        setText(Integer.toString(num));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                if (CaseMalus.this.isEnabled()) {
                    try {
                        if (num != numCaseCourante) {
                            throw new DeplacementException();
                        }
                        numCaseCourante -= 2;//reculer de deux cases
                        joueur.setScoreduj(joueur.getScoreduj() - 10);//augmenter le score du joueur
                        info.tfScoreJoueur.setText(Integer.toString(joueur.getScoreduj()));
                        if (numCaseCourante < 0) {//la case où aller n'existe pas ( < 0)
                            numCaseCourante = 1;
                        }
                    } catch (DeplacementException de) {
                        de.getMessage();
                    }
                }
                //mettre à jour l'affichage
                info.tfCaseActuelle.setText(Integer.toString(numCaseCourante));
            }
        });
    }

    //retourner le type de la case
    @Override
    public String toString() {
        return "3";
    }
}
