/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 *
 * @author mohammed_bey
 */
public class FenetreMeilleuresScores extends JFrame {

    public FenetreMeilleuresScores(String str) throws FileNotFoundException, IOException {
        //rendre l'arriere plan de la fenetre 'blanche'
        getContentPane().setBackground(Color.WHITE);
        setTitle("Les meilleurs scores du jeu");
        setSize(500, 500);
        setResizable(false);
        //centrer la fenetre
        this.setLocationRelativeTo(null);
        //enlever les layouts de la fenetre
        getContentPane().setLayout(null);
        //créer un tableau des noms des joueurs avec les meilleurs scores
        JPanel panel = setBackgroundImage(this, new File("fenetreDemarrage.jpg"));
        setContentPane(panel);
        panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));

        Box box = Box.createVerticalBox();
        box.add(Box.createVerticalStrut(150));
        box.setBackground(Color.WHITE);
        JScrollPane scrollBar = new JScrollPane();
        //créer un tableau des meilleurs scores à partir du fichier contenant les meilleurs scores
        String tabMeillScores[] = str.split("\n");
        Object[][] data = new Object[tabMeillScores.length][2];
        //remplir le tableau des joueurs avec leurs acores respectifs
        for (int i = 0; i < tabMeillScores.length; i++) {
            String tabLigneMeiSc[] = tabMeillScores[i].split("#");//un tableau qui contient une ligne du fichier des meilleurs scores
            data[i][0] = tabLigneMeiSc[1];
            data[i][1] = tabLigneMeiSc[0];
        }
        //définir un tableau qui contient les titres du tableau d'affichage
        String titres[] = {"Joueur", "Score"};
        //le tableau d'affichage
        JTable tableau = new JTable(data, titres);
        //définir la hauteur d'une grille du tableau
        tableau.setRowHeight(30);
        //rendre la tableau inmodifiable
        tableau.setEnabled(false);
        scrollBar.setAutoscrolls(true);
        scrollBar.getViewport().add(tableau);
        box.add(scrollBar);
        scrollBar.setBackground(Color.BLUE);
        //ajouter le tableau à la fenetre
        getContentPane().add(box);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//Terminer le processus lorsqu'on clique sur "Fermer"
        show();
    }

    public static JPanel setBackgroundImage(JFrame frame, final File img) throws IOException {
        JPanel panel = new JPanel() {
            private static final long serialVersionUID = 1;
            private final BufferedImage buf = ImageIO.read(img);

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(buf, 0, 0, null);
            }
        };
        panel.setBackground(Color.white);
        frame.setContentPane(panel);
        return panel;
    }
}
