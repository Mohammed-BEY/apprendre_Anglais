/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.io.Serializable;

/**
 *
 * @author mohammed_bey
 */
public class Sauvegarde implements Serializable {

    //les informations concernant le joueur
    String nomJoueur;
    int scoreJoueur;
    int meilScJoeur;
    //la case où le jeu s'est arrêté
    int numCaseActuelle;
    //le tableau des types des cases
    int tabtypCases[];

    public Sauvegarde(String nomJoueur, int scoreJoueur, int meilScJoeur, int numCaseActuelle, int tabtypCases[]) {
        this.nomJoueur = nomJoueur;
        this.scoreJoueur = scoreJoueur;
        this.meilScJoeur = meilScJoeur;
        this.numCaseActuelle = numCaseActuelle;
        this.tabtypCases = tabtypCases;
    }

    @Override
    public String toString() {
        String str = "";
        for (int i = 0; i < 100; i++) {
            str += Integer.toString(this.tabtypCases[i]);
        }
        return "nom du joueur: " + this.nomJoueur + "\n"
                + "score du joueur: " + this.scoreJoueur + "\n"
                + "meilleur score du joueur: " + this.meilScJoeur + "\n"
                + "num de la case actuelle: " + this.numCaseActuelle + "\n"
                + "le tableau des types des cases:" + str;
    }
}
