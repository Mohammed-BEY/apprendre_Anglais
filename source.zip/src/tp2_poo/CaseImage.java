/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import javax.swing.JOptionPane;
import static tp2_poo.FenetrePartie.numCaseCourante;

/**
 *
 * @author mohammed_bey
 */
public class CaseImage extends CaseQuestion {

    private int dernieIndiceUtilise = -1;//sauvegarder le dernier indice visité dans le tableau
    boolean acces = true;//indique si la réponse donnée par le joueur est correcte ou pas
    String tabImage[];
    List<String> tabIm;
    FenetreQimage fenImage = null;//la fenetre des images

    public CaseImage(final InfoJeu info, final DiceGame de, final JoueurTP joueur, final int num, String decoIm) throws DeplacementException, ReponseException {
//        this.setIcon(new ImageIcon("record.png"));
        setBackground(Color.PINK);
        setText(Integer.toString(num));
        //créer un tableau des mots avec leurs images proposées (respectives)
        tabImage = decoIm.split("&");
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                if (CaseImage.this.isEnabled() && fenImage == null) {//verifier si la partie est en pause
                    try {
                        if (num != numCaseCourante) {
                            throw new DeplacementException();
                        }
                        //generer une case aleatoire dans le tableau
                        int random = (int) (Math.random() * (tabImage.length));
                        while (random == dernieIndiceUtilise) {
                            random = (int) (Math.random() * (tabImage.length));
                        }
                        dernieIndiceUtilise = random;//modifier la valeur du dernier indice utilisé
                        //decouper la chaine obtenue de la liste dans un tableau selon le caractere special '#'
                        final String tabUrl[] = tabImage[random].split("#");
                        String bonUrl = tabUrl[1], mot = tabUrl[0];
                        //créer une liste des urls des images pour les mélanger
                        tabIm = Arrays.asList(tabUrl);//transformer le tableau en une liste
                        tabIm = tabIm.subList(1, 5);//extraire uniquement les urls
                        Collections.shuffle(tabIm);//melanger les urls des images aléatoirement
                        fenImage = new FenetreQimage(bonUrl, mot, tabIm, joueur, info, de);
                        /**
                         * **Gestion des evenements ***
                         */
                        fenImage.bValider.addMouseListener(new MouseAdapter() {
                            @Override
                            public void mouseClicked(MouseEvent me) {
                                if (fenImage.rbImage1.isSelected()) {//la premiere image est choisie
                                    if (((String) tabIm.get(0)).equals(tabUrl[1])) {
                                        numCaseCourante += 2;//avancer de deux cases
                                        joueur.setScoreduj(joueur.getScoreduj() + 10);//augmenter le score du joueur
                                        info.tfScoreJoueur.setText(Integer.toString(joueur.getScoreduj()));
                                        if (numCaseCourante > 100) {//la case où aller dépasse la derniére case du jeu
                                            numCaseCourante = 100 - (numCaseCourante - 100);
                                        }
                                        JOptionPane.showMessageDialog(null, "Bravo ! vous avez trouvé le mot correspondant");                                        
                                    } else {
                                        JOptionPane.showMessageDialog(null, "Désolé ! veuillez relancer le dé pour continuer !");
                                        de.bouton.setEnabled(true);
                                        acces = false;
                                    }
                                    fenImage.dispose();
                                } else if (fenImage.rbImage2.isSelected()) {//la deuxieme image est choisie
                                    if (((String) tabIm.get(1)).equals(tabUrl[1])) {
                                        numCaseCourante += 2;//avancer de deux cases
                                        joueur.setScoreduj(joueur.getScoreduj() + 10);//augmenter le score du joueur
                                        info.tfScoreJoueur.setText(Integer.toString(joueur.getScoreduj()));
                                        if (numCaseCourante > 100) {//la case où aller dépasse la derniére case du jeu
                                            numCaseCourante = 100 - (numCaseCourante - 100);
                                        }
                                        JOptionPane.showMessageDialog(null, "Bravo ! vous avez trouvé le mot correspondant");
                                    } else {
                                        JOptionPane.showMessageDialog(null, "Désolé ! veuillez relancer le dé pour continuer");
                                        de.bouton.setEnabled(true);
                                        acces = false;
                                    }
                                    fenImage.dispose();
                                } else if (fenImage.rbImage3.isSelected()) {//la roisieme image est choisie
                                    if (((String) tabIm.get(2)).equals(tabUrl[1])) {
                                        numCaseCourante += 2;//vancer de deux cases
                                        joueur.setScoreduj(joueur.getScoreduj() + 10);//augmenter le score du joueur
                                        info.tfScoreJoueur.setText(Integer.toString(joueur.getScoreduj()));
                                        if (numCaseCourante > 100) {//la case où aller dépasse la derniére case du jeu
                                            numCaseCourante = 100 - (numCaseCourante - 100);
                                        }
                                        JOptionPane.showMessageDialog(null, "Bravo ! vous avez trouvé le mot correspondant");
                                    } else {
                                        JOptionPane.showMessageDialog(null, "Désolé ! veuillez relancer le dé pour continuer");
                                        de.bouton.setEnabled(true);
                                        acces = false;
                                    }
                                    fenImage.dispose();
                                } else if (fenImage.rbImage4.isSelected()) {//la qutrieme image est choisie
                                    if (((String) tabIm.get(3)).equals(tabUrl[1])) {
                                        numCaseCourante += 2;//avancer de deux cases
                                        joueur.setScoreduj(joueur.getScoreduj() + 10);//augmenter le score du joueur
                                        info.tfScoreJoueur.setText(Integer.toString(joueur.getScoreduj()));
                                        if (numCaseCourante > 100) {//la case où aller dépasse la derniére case du jeu
                                            numCaseCourante = 100 - (numCaseCourante - 100);
                                        }
                                        JOptionPane.showMessageDialog(null, "Bravo ! vous avez trouvé le mot correspondant");
                                    } else {
                                        JOptionPane.showMessageDialog(null, "Désolé ! veuillez relancer le dé pour continuer");
                                        de.bouton.setEnabled(true);
                                        acces = false;
                                    }
                                    fenImage.dispose();
                                }
                            }
                        });
                    } catch (DeplacementException ex) {
                    }
                } else {
                    try {
                        if (!acces) {//si la réponse donnée par le joueur est fausse
                            throw new ReponseException();
                        }
                    } catch (ReponseException ex) {
                    }
                }
                //mettre à jour l'affichage
                info.tfCaseActuelle.setText(Integer.toString(numCaseCourante));
            }
        });
    }

    //retourner le type de la case
    @Override
    public String toString() {
        return "6";
    }
}
