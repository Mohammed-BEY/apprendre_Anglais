/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class FenetreQdefinition extends JFrame {

    JLabel lablDevintte;
    JLabel lablDefinition;
    JPanel panelDeSaisi;
    JButton valider;
    JTextField saisi[];
    String tableauDemotEtDefinition[] = new String[1000];
    String tabMotDefSéparer[] = new String[2];
    Boolean reponse;

    @SuppressWarnings("empty-statement")
    public FenetreQdefinition(int i, String def) {
        setTitle("Définition"); // Le titre de ma fenetre
        setSize(500, 250);
        setResizable(false);
        getContentPane().setBackground(Color.WHITE);
        //centrer la fenetre
        this.setLocationRelativeTo(null);
        //enlever les layouts de la fenetre
        getContentPane().setLayout(null);
        lablDevintte = new JLabel("which word refers to this definition : ");
        lablDefinition = new LabelMotAnglais(def);
        //instancier le conteneur des champs de saisie
        panelDeSaisi = new JPanel();
        //instancier le bouton de validation
        valider = new JButton("valider");
        //créer le tableau des champs de saisie
        saisi = new JTextField[i];
        for (int k = 0; k < i; k++) {
            saisi[k] = new JTextField(1);
            panelDeSaisi.add(saisi[k]);
        }
        //ajouter les composants à la fenêtre
        add(lablDevintte);
        add(lablDefinition);
        add(panelDeSaisi);
        add(valider);
        //positionner les composants dans le fenêtre
        lablDevintte.setBounds((getWidth() - 39 * 6)/2, 20, 250, 33);
        lablDefinition.setBounds((getWidth() - i * 12) / 2, 50, 500, 33);
        panelDeSaisi.setBounds((getWidth() - i * 20) / 2, 100, i * 20, 33);
        valider.setBounds((getWidth() - 150) / 2, 160, 150, 33);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//Terminer le processus lorsqu'on clique sur "Fermer"
        show();
    }

    public boolean champVide(JTextField saisi[]) {
        boolean result = false;
        for (JTextField saisi1 : saisi) {
            if (saisi1.getText().equals("")) {
                result = true;
            }
        }
        return result;
    }

    public String chamSaisi(JTextField saisi[]) {
        String result = "";
        for (JTextField saisi1 : saisi) {
            result += saisi1.getText().charAt(0);
        }
        return result;
    }
}
