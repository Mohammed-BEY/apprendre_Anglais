/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.FlowLayout;
import java.util.List;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

/**
 *
 * @author mohammed_bey
 */
public final class FenetreQimage extends JFrame {

    JRadioButton rbImage1, rbImage2, rbImage3, rbImage4;
    JLabel labMessage, labMot;
    JButton bValider;
    String urlIm1, urlIm2, urlIm3, urlIm4;
    //definir les images        
    JLabel labRb1, labRb2, labRb3, labRb4;

    public FenetreQimage(final String bonUrl, String mot, final List tabIm, final JoueurTP joueur, final InfoJeu info, final DiceGame de) {
        //rendre l'arriere plan de la fenetre 'blanche'
        getContentPane().setBackground(Color.WHITE);
        setTitle("Jeu de l'oie");
        setSize(400, 500);
        setResizable(false);
        //centrer la fenetre
        this.setLocationRelativeTo(null);
        //enlever les layouts de la fenetre
        getContentPane().setLayout(null);
        //definir les labels des images
        labRb1 = new JLabel(new ImageIcon((String) tabIm.get(0)));
        labRb2 = new JLabel(new ImageIcon((String) tabIm.get(1)));
        labRb3 = new JLabel(new ImageIcon((String) tabIm.get(2)));
        labRb4 = new JLabel(new ImageIcon((String) tabIm.get(3)));
        //définir les layouts
        labRb1.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 150));
        labRb2.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 150));
        labRb3.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 50));
        labRb4.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 50));
        //définir les boutons de choix
        rbImage1 = new JRadioButton();
        rbImage2 = new JRadioButton();
        rbImage3 = new JRadioButton();
        rbImage4 = new JRadioButton();

        //creer un groupe qui rassemble les radiboutons
        ButtonGroup bg = new ButtonGroup();
        bg.add(rbImage1);
        bg.add(rbImage2);
        bg.add(rbImage3);
        bg.add(rbImage4);
        //definir les Panels inrermidiaires
        JPanel panRb1 = new JPanel(), panRb2 = new JPanel(), panRb3 = new JPanel(), panRb4 = new JPanel();
        //ajouter les images et les boutons aux conteneurs approporiés
        panRb1.add(labRb1);
        panRb1.add(rbImage1);
        panRb2.add(labRb2);
        panRb2.add(rbImage2);
        panRb3.add(labRb3);
        panRb3.add(rbImage3);
        panRb4.add(labRb4);
        panRb4.add(rbImage4);
        //definir le message du Label
        labMessage = new JLabel("À quelle image correspond le mot : ");
        labMot = new LabelMotAnglais(mot + " ?");
        //instancier le bouton de validation
        bValider = new JButton("valider");
        //ajouter les images à la fenetre
        add(panRb1);
        add(panRb2);
        add(panRb3);
        add(panRb4);
        add(labMessage);
        add(labMot);
        add(bValider);
        //positionner les images dans la fentere
        panRb1.setBounds(50, 10, 128, 128 + 30);
        panRb2.setBounds(222, 10, 128, 128 + 30);
        panRb3.setBounds(50, 170, 128, 128 + 30);
        panRb4.setBounds(222, 170, 128, 128 + 30);
        labMessage.setBounds(50, 380, 400, 33);
        labMot.setBounds(255, 380, mot.length() * 16, 33);
        bValider.setBounds(120, 430, 150, 33);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//Terminer le processus lorsqu'on clique sur "Fermer"
        show();
    }
}
