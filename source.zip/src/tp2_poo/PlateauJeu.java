/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

/**
 *
 * @author mohammed_bey
 */
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.Hashtable;
import javax.swing.JPanel;

public final class PlateauJeu extends JPanel {

    private boolean chargerPartie;//indique si on veut créer une nouvellle partie on charger une partie déjà sauvegardée

    private int tabCases[];//contient les types des cases , sert à la sauvegarder et à la restitution
    /*
     *0 ->Case de départ    ->Jaune
     *1 ->Case de fin       ->noire
     *2 ->Case de bonus     ->Verte
     *3 ->Case malus        ->Rouge
     *4 ->Case saut         ->Orange
     *5 ->Case définition   ->?
     *6 ->Case image        ->?
     *7 ->Case de parcourt  ->?
     */
    Hashtable<Integer, CaseJeu> tabAleatoire = new Hashtable<>();
    GridBagLayout gbl = new GridBagLayout();
    GridBagConstraints gbc = new GridBagConstraints();

    public PlateauJeu() {
    }

    //permet de créer le spirale du jeu
    public void creerSpirale(InfoJeu info, DiceGame de, JoueurTP joueur, String decoJeu) throws DeplacementException, ReponseException {
        tableau_aleatoire(info, de, joueur, decoJeu);//remplir le tableau des cases aleatoirement.
        Integer nbCase = 0;
        boolean fin = false;
        /*Une variable qui controle le parcourt ou la création (Ligne ou colone)*/
        boolean Horizontal = true;
        int i = 0, j = 0;
        /*Des varibles qui controlent gridx et gridy de gbc(grid bag constreints)*/
        int addX = 1, addY = 1, nbreMaxLigne = 14, nbreMaxColonne = 14;//nombre maximal des boutons dans un ligne et dans une colonne
        /*Une variable qui controle la direction soit aller soit retour*/
        boolean retour = false;
        /*Ce tableau va contenir le contenu de la spirale*/
        gbc.fill = GridBagConstraints.BOTH;
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.ipadx = 15;
        gbc.ipady = 15;
        /*Pour eliminer la couleur du JPanel*/
        this.setOpaque(false);
        this.setLayout(gbl);
        while (nbCase < 100 && !fin) {
            if (nbreMaxLigne <= 0 || nbreMaxColonne <= 0) {
                System.out.println("L'une des POS est nulle " + fin);
                fin = true;
            } else {
                if (Horizontal) {
                    i = 0;
                    while (i < nbreMaxLigne && nbCase < 100) {
                        gbl.setConstraints(tabAleatoire.get(nbCase), gbc);
                        this.add(tabAleatoire.get(nbCase));
                        nbCase++;
                        gbc.gridx += addX;
                        i++;
                    }
                    gbc.gridx += -addX;
                    gbc.gridy += addY;
                    Horizontal = false;
                    nbreMaxLigne--;
                    nbreMaxColonne--;
                } else {
                    j = 0;
                    while (j < nbreMaxColonne && nbCase < 100) {
                        gbl.setConstraints(tabAleatoire.get(nbCase), gbc);
                        this.add(tabAleatoire.get(nbCase));
                        gbc.gridy += addY;
                        nbCase++;
                        j++;
                    }
                    gbc.gridy += -addY;
                    Horizontal = true;
                    addX = -addX;
                    addY = -addY;
                    gbc.gridx += addY;
                    retour = !retour;
                    nbreMaxLigne--;
                    nbreMaxColonne--;
                }
            }
        }
    }

    //La methode qui génère les cases aléatoirement
    public void tableau_aleatoire(InfoJeu info, DiceGame de, JoueurTP joueur, String decoJeu) throws DeplacementException, ReponseException {
        //créer les dictionnaires des images et des définitions
        String tabDeco[] = decoJeu.split(";");
        if (isChargerPartie()) {
            for (int i = 0; i < 100; i++) {
                switch (tabCases[i]) {
                    case 0:
                        this.tabAleatoire.put(i, new CaseDepart(info, de));
                        break;
                    case 1:
                        this.tabAleatoire.put(i, new CaseFin(info, de, joueur));
                        break;
                    case 2:
                        this.tabAleatoire.put(i, new CaseBonus(info, de, joueur, i + 1));
                        break;
                    case 3:
                        this.tabAleatoire.put(i, new CaseMalus(info, de, joueur, i + 1));
                        break;
                    case 4:
                        this.tabAleatoire.put(i, new CaseSaut(info, de, i + 1));
                        break;
                    case 5:
                        this.tabAleatoire.put(i, new CaseDefinition(info, de, joueur, i + 1, tabDeco[0]));
                        break;
                    case 6:
                        this.tabAleatoire.put(i, new CaseImage(info, de, joueur, i + 1, tabDeco[0]));
                        break;
                    case 7:
                        this.tabAleatoire.put(i, new CaseParcours(info, de, i + 1));
                        break;
                    default:
                        throw new AssertionError();
                }
            }
        } else {
            int random;
            /*
             *0 ->Case de départ    ->Jaune
             *1 ->Case de fin       ->noire
             *2 ->Case de bonus     ->Verte
             *3 ->Case malus        ->Rouge
             *4 ->Case saut         ->Orange
             *5 ->Case définition   ->?
             *6 ->Case image        ->?
             *7 ->Case de parcourt  ->?
             */

            this.tabAleatoire.put(0, new CaseDepart(info, de));
            this.tabAleatoire.put(99, new CaseFin(info, de, joueur));
            int i = 0;
            int nbCase = 2;
            Integer type = 2;
            while (nbCase < 100) {
                if (type < 7) {
                    while (i < 5) {
                        random = (int) (Math.random() * 100);
                        if (!tabAleatoire.containsKey(random)) {
                            switch (type) {
                                case 2://generer les cases de type Bonus
                                    //verifier si la case précédente n'est pas vide et ne contient pas pas la même case que la courante
                                    while ((this.tabAleatoire.get(random - 1) != null && this.tabAleatoire.get(random - 1) instanceof CaseBonus)
                                            || (this.tabAleatoire.get(random + 1) != null && this.tabAleatoire.get(random + 1) instanceof CaseBonus)) {
                                        random = (int) (Math.random() * 100);
                                    }
                                    if (!tabAleatoire.containsKey(random)) {//verifier si l tableau contient déjà cette valeur
                                        this.tabAleatoire.put(random, new CaseBonus(info, de, joueur, random + 1));
                                        nbCase++;
                                        i++;
                                    }
                                    break;
                                case 3://generer les cases de type Malus
                                    while (((this.tabAleatoire.get(random - 1) != null && this.tabAleatoire.get(random - 1) instanceof CaseMalus)
                                            || (this.tabAleatoire.get(random + 1) != null && this.tabAleatoire.get(random + 1) instanceof CaseMalus))
                                            || (this.tabAleatoire.get(random - 2) != null && this.tabAleatoire.get(random - 2) instanceof CaseBonus)) {//interdire que la case qui précéde la case Malus de deux positions soit de type Bonus
                                        random = (int) (Math.random() * 100);
                                    }
                                    if (!tabAleatoire.containsKey(random)) {
                                        this.tabAleatoire.put(random, new CaseMalus(info, de, joueur, random + 1));
                                        nbCase++;
                                        i++;
                                    }
                                    break;
                                case 4://generer les cases de type Saut
                                    while ((this.tabAleatoire.get(random - 1) != null && this.tabAleatoire.get(random - 1) instanceof CaseSaut)
                                            || (this.tabAleatoire.get(random + 1) != null && this.tabAleatoire.get(random + 1) instanceof CaseSaut)) {
                                        random = (int) (Math.random() * 100);
                                    }
                                    if (!tabAleatoire.containsKey(random)) {
                                        this.tabAleatoire.put(random, new CaseSaut(info, de, random + 1));
                                        nbCase++;
                                        i++;
                                    }
                                    break;
                                case 5://generer les cases de type Definition
                                    while ((this.tabAleatoire.get(random - 1) != null && this.tabAleatoire.get(random - 1) instanceof CaseDefinition)
                                            || (this.tabAleatoire.get(random + 1) != null && this.tabAleatoire.get(random + 1) instanceof CaseDefinition)) {
                                        random = (int) (Math.random() * 100);
                                    }
                                    if (!tabAleatoire.containsKey(random)) {
                                        this.tabAleatoire.put(random, new CaseDefinition(info, de, joueur, random + 1, tabDeco[0]));
                                        nbCase++;
                                        i++;
                                    }
                                    break;
                                case 6://generer les cases de type Image                                
                                    while ((this.tabAleatoire.get(random - 1) != null && this.tabAleatoire.get(random - 1) instanceof CaseImage)
                                            || (this.tabAleatoire.get(random + 1) != null && this.tabAleatoire.get(random + 1) instanceof CaseImage)) {
                                        random = (int) (Math.random() * 100);
                                    }
                                    if (!tabAleatoire.containsKey(random)) {
                                        this.tabAleatoire.put(random, new CaseImage(info, de, joueur, random + 1, tabDeco[1]));
                                        nbCase++;
                                        i++;
                                    }
                                    break;
                            }
                        }
                    }
                    i = 0;
                    type++;
                } else {
                    random = (int) (Math.random() * 100);
                    if (!tabAleatoire.containsKey(random)) {
                        this.tabAleatoire.put(random, new CaseParcours(info, de, random + 1));
                        nbCase++;
                    }
                }
            }
        }
    }

    //remplir le tableau des types des cases
    public int[] tabTypesCase() {
        int tabRetour[] = new int[tabCases.length];
        for (int i = 0; i < tabCases.length; i++) {
            tabRetour[i] = 0;
        }
        System.arraycopy(tabCases, 0, tabRetour, 0, tabRetour.length);
        return null;
    }

    //Les getters
    public boolean isChargerPartie() {
        return chargerPartie;
    }

    //Les setters
    public void setNouvPartie(boolean nouvPartie) {
        this.chargerPartie = nouvPartie;
    }

    public void setTabCases(int[] tabCases) {
        this.tabCases = tabCases;
    }
}
