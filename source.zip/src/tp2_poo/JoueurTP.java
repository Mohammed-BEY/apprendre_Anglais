/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

/**
 *
 * @author mohammed_bey
 */
public class JoueurTP {

    public String nom;
    public int scoreduj;
    public int meileurScorej;

    public JoueurTP() {
        nom = "";
        scoreduj = 0;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public void setScoreduj(int scoreduj) {
        this.scoreduj = scoreduj;
    }

    public void setMeileurScorej(int meileurScorej) {
        this.meileurScorej = meileurScorej;
    }

    public String getNom() {
        return nom;
    }

    public int getScoreduj() {
        return scoreduj;
    }

    public int getMeileurScorej() {
        return meileurScorej;
    }

}
