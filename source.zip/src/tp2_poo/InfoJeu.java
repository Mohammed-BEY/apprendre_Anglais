/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

/**
 *
 * @author mohammed_bey
 */
public class InfoJeu extends JPanel {

    JTextField tfNomJoueur, tfScoreJoueur, tfMeilleurSCoreJeu,tfCaseActuelle;

    public InfoJeu() {
        setBackground(Color.WHITE);
        setPreferredSize(new Dimension(180, 0));
        setLayout(new FlowLayout(FlowLayout.CENTER, 0, 10));
        //deficir les labels de l'affichage
        JLabel labNom = new JLabel("nom du joueur : ");
        tfNomJoueur = new JTextField();
        tfNomJoueur.setEditable(false);
        JLabel labScore = new JLabel("scroe : ");
        tfScoreJoueur = new JTextField("0");
        tfScoreJoueur.setEditable(false);
        JLabel labMeilleurSCore = new JLabel("score à battre : ");
        tfMeilleurSCoreJeu = new JTextField();
        tfMeilleurSCoreJeu.setEditable(false);
        JLabel labCaseCourante = new JLabel("case actuelle : ");
        tfCaseActuelle = new JTextField("1");
        tfCaseActuelle.setEditable(false);
        //redimensionner les labels
        labNom.setPreferredSize(new Dimension(150, 25));
        tfNomJoueur.setPreferredSize(new Dimension(150, 25));
        labScore.setPreferredSize(new Dimension(150, 25));
        tfScoreJoueur.setPreferredSize(new Dimension(150, 25));
        labMeilleurSCore.setPreferredSize(new Dimension(150, 25));
        tfMeilleurSCoreJeu.setPreferredSize(new Dimension(150, 25));
        labCaseCourante.setPreferredSize(new Dimension(150, 25));
        tfCaseActuelle.setPreferredSize(new Dimension(150, 25));
        //ajouter les elements au conteneur
        tfNomJoueur.setOpaque(false);
        tfScoreJoueur.setOpaque(false);
        tfMeilleurSCoreJeu.setOpaque(false);
        tfCaseActuelle.setOpaque(false);
        //
        add(labNom);
        add(tfNomJoueur);
        add(labScore);
        add(tfScoreJoueur);
        add(labMeilleurSCore);
        add(tfMeilleurSCoreJeu);
        add(labCaseCourante);
        add(tfCaseActuelle);
    }
}
