/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.Box;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;

/**
 *
 * @author mohammed_bey
 */
public class FenetreFin extends JFrame {

    JButton bConsulterMeiSc;

    public FenetreFin(JoueurTP joueur, InfoJeu info, final String meilleureScores) throws IOException {
        //rendre l'arriere plan de la fenetre 'blanche'
        getContentPane().setBackground(Color.WHITE);
        setTitle("fin de la partie");
        setSize(500, 500);
        setResizable(false);
        //centrer la fenetre
        this.setLocationRelativeTo(null);
        //enlever les layouts de la fenetre
        getContentPane().setLayout(null);
        //
        bConsulterMeiSc = new JButton("consulter les meilleurs scores");
        //extraire le champion du jeu du fichier des meilleurs scores
        String tab[] = meilleureScores.split("\n");
        final String champion[] = tab[0].split("#");
        //créer un tableau des noms des joueurs avec les meilleurs scores
        JPanel panel = setBackgroundImage(this, new File("fenetreDemarrage.jpg"));
        panel.setLayout(null);
        setContentPane(panel);
        //
        Box box = Box.createVerticalBox();
        box.add(Box.createVerticalStrut(0));
        box.add(Box.createHorizontalStrut(0));
        box.setBackground(Color.WHITE);
        JScrollPane scrollBar = new JScrollPane();

        Object[][] data = new Object[5][2];
        //remplir le tableau des joueurs avec leurs acores respectifs
        data[0][0] = "nom du joueur";
        data[0][1] = joueur.nom;
        data[1][0] = "score du jeu ";
        data[1][1] = joueur.scoreduj;
        data[2][0] = "meilleur score du joueur";
        data[2][1] = joueur.meileurScorej;
        data[3][0] = "meilleur score du jeu ";
        data[3][1] = champion[0];
        data[4][0] = "le champion du jeu ";
        data[4][1] = champion[1];
        //
        //définir un tableau qui contient les titres du tableau d'affichage
        String titres[] = {"titre", "descroption"};
        //le tableau d'affichage
        JTable tableau = new JTable(data, titres);
        //
        tableau.setRowHeight(50);
        //rendre la tableau inmodifiable
        tableau.setEnabled(false);
        scrollBar.setAutoscrolls(true);
        box.setBackground(Color.WHITE);
        scrollBar.setPreferredSize(new Dimension(500, 250));
        scrollBar.getViewport().add(tableau);
        box.add(scrollBar);
        scrollBar.setBackground(Color.BLUE);
        //ajouter le tableau à la fenetre
        panel.add(box);
        JLabel lab = new JLabel(new ImageIcon("oiseau16.gif"));
        panel.add(lab);
//        getContentPane().add(box);
        panel.add(bConsulterMeiSc);
        //repositionner les composants
        box.setBounds(0, 0, 500, 300);
        lab.setBounds(0, 300, 500, 128);
        bConsulterMeiSc.setBounds(120, 300 + 128, 250, 33);
        //associer une action au bouton de l'afffichage des meilleurs scores
        //afficher les meilleurs scores
        bConsulterMeiSc.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                try {
                    FenetreMeilleuresScores fenMeilleuresScores = new FenetreMeilleuresScores(meilleureScores);
                } catch (IOException ex) {
                }
            }
        });
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//Terminer le processus lorsqu'on clique sur "Fermer"
        show();
    }

    public static JPanel setBackgroundImage(JFrame frame, final File img) throws IOException {
        JPanel panel = new JPanel() {
            private static final long serialVersionUID = 1;
            private final BufferedImage buf = ImageIO.read(img);

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(buf, 0, 0, null);
            }
        };
        panel.setBackground(Color.white);
        frame.setContentPane(panel);
        return panel;
    }
}
