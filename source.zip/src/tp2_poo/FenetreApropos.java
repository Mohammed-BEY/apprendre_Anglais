/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import javax.swing.JFrame;

/**
 *
 * @author mohammed_bey
 */
public class FenetreApropos extends JFrame {

    public FenetreApropos() {
        //rendre l'arriere plan de la fenetre 'blanche'
        getContentPane().setBackground(Color.WHITE);
        setTitle("À propos du jeu");
        setSize(500, 500);
        setResizable(false);
        //centrer la fenetre
        this.setLocationRelativeTo(null);
        //enlever les layouts de la fenetre
        getContentPane().setLayout(null);

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//Terminer le processus lorsqu'on clique sur "Fermer"
        show();
    }
}
