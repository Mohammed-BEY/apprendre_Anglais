/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import javax.swing.JOptionPane;
import static tp2_poo.FenetrePartie.numCaseCourante;

/**
 *
 * @author mohammed_bey
 */
public class DeplacementException extends Exception {

    public DeplacementException() {
        JOptionPane.showMessageDialog(null, "il faut aller vers la case : " + Integer.toString(numCaseCourante));
    }
}
