/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import static tp2_poo.FenetrePartie.numCaseCourante;

/**
 *
 * @author mohammed_bey
 */
public class CaseSaut extends CaseJeu {

    public CaseSaut(final InfoJeu info, DiceGame de, final int num) {
        super();
//        this.setIcon(new ImageIcon("record.png"));
        setBackground(Color.ORANGE);
        setText(Integer.toString(num));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                if (CaseSaut.this.isEnabled()) {
                    try {
                        if (num != numCaseCourante) {
                            throw new DeplacementException();
                        }
                        int random = (int) (Math.random() * (100 - 1)) + 1;
                        while (random == num) {
                            random = (int) (Math.random() * (100 - 1)) + 1;
                        }
                        JOptionPane.showConfirmDialog(null, "il faut aller vers la case : " + Integer.toString(random), "case d'avancement", JOptionPane.CLOSED_OPTION);
                        numCaseCourante = random;
                    } catch (DeplacementException de) {
                        de.getMessage();
                    }
                }
                //mettre à jour l'affichage
                info.tfCaseActuelle.setText(Integer.toString(numCaseCourante));
            }
        });
    }

    //retourner le type de la case
    @Override
    public String toString() {
        return "4";
    }

}
