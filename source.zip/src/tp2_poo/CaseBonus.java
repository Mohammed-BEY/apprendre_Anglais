/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import static tp2_poo.FenetrePartie.numCaseCourante;

/**
 *
 * @author mohammed_bey
 */
public class CaseBonus extends CaseJeu {

    public CaseBonus(final InfoJeu info, DiceGame de, final JoueurTP joueur, final int num) {
        super();
//        this.setIcon(new ImageIcon("add.png"));
        setText(Integer.toString(num));
        setBackground(Color.GREEN);
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                if (CaseBonus.this.isEnabled()) {
                    try {
                        if (num != numCaseCourante) {
                            throw new DeplacementException();
                        }
                        joueur.setScoreduj(joueur.getScoreduj() + 10);
                        info.tfScoreJoueur.setText(Integer.toString(joueur.getScoreduj()));
                        numCaseCourante += 2;
                        info.tfCaseActuelle.setText(Integer.toString(numCaseCourante));
                        if (numCaseCourante > 100) {//la case où aller dépasse la derniére case du jeu
                            numCaseCourante = 100 - (numCaseCourante - 100);
                        }
                    } catch (DeplacementException de) {
                        de.getMessage();
                    }
                }
            }
        });
    }

    //retourner le type de la case
    @Override
    public String toString() {
        return "2";
    }
}
