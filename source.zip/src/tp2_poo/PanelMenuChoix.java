/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 *
 * @author mohammed_bey
 */
public class PanelMenuChoix extends JPanel {

    JButton bSuspendre, bMenu, bNouvellePartie, bQuiter;

    public PanelMenuChoix() {
        setPreferredSize(new Dimension(180, 0));
        setLayout(new FlowLayout(FlowLayout.CENTER, 0, 50));
        setBackground(Color.WHITE);
        //créer un tableau des noms des joueurs avec les meilleurs scores
        //instancier les boutons
        bSuspendre = new JButton("suspendre");
        bMenu = new JButton("menu");
        bNouvellePartie = new JButton("nouvelle partie");
        bQuiter = new JButton("quitter");
        //redimensionner 
        bSuspendre.setPreferredSize(new Dimension(150, 33));
        bMenu.setPreferredSize(new Dimension(150, 33));
        bNouvellePartie.setPreferredSize(new Dimension(150, 33));
        bQuiter.setPreferredSize(new Dimension(150, 33));
        //ajouter les boutons au conteneur
        add(bSuspendre);
        add(bMenu);
        add(bNouvellePartie);
        add(bQuiter);
        
        bMenu.setBackground(Color.red);
        bNouvellePartie.setBackground(Color.red);
        bQuiter.setBackground(Color.red);
        bSuspendre.setBackground(Color.red);        
    }
}
