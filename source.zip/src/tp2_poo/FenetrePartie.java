/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 *
 * @author mohammed_bey
 */
public final class FenetrePartie extends JFrame {

    //les conteneurs des composants de la fenetre de a partie du jeu
    private final JPanel panelWest = new JPanel(), panelEast = new JPanel();
    JPanel panelPlateau;
    public PlateauJeu plateau;
    private PanelMenuChoix pChoix;
    private final LogoApprentissageAnglais logoAp;
    public InfoJeu info;
    private final DiceGame de;
    private JoueurTP joueur;

    public JoueurTP getJoueur() {
        return joueur;
    }
    static int numCaseCourante = 1;//indique le numéro de la case courante
    int tabTypCases[] = new int[100];

    public FenetrePartie(String nomJoueur, final String decoJeu, final String champion[], boolean chargerPartie, final int tabTypCasesCharges[]) throws IOException, DeplacementException, ReponseException {
        setSize(new Dimension(1366, 768));
        setTitle("jeu de l'oie");
//        setExtendedState(JFrame.MAXIMIZED_BOTH);//mettre la fenetre en plein ecran
//        setUndecorated(true);
        //On définit le layout à utiliser sur le contentPane        
        getContentPane().setBackground(Color.WHITE);
        setLayout(null);
        setLocationRelativeTo(null);//centrer la fenetre
        panelWest.setLayout(new GridLayout(2, 1, 0, 50));//
        panelWest.setBackground(Color.WHITE);
        panelEast.setLayout(new GridLayout(2, 1, 0, 50));//
        panelEast.setBackground(Color.WHITE);
        //initialiser un nouveau joueur
        joueur = new JoueurTP();
        joueur.setNom(nomJoueur);//modifier le nom du joueur
        //Les elements de la partie gauche du jeu
        info = new InfoJeu();
        de = new DiceGame();
        de.info = info;
        panelWest.add(info);
        panelWest.add(de);
        //initialiser l'affichage
        info.tfScoreJoueur.setText("0");
        info.tfNomJoueur.setText(nomJoueur);
        info.tfMeilleurSCoreJeu.setText(champion[0]);

        //ajouter le plateu au jeu
        plateau = new PlateauJeu();
        if (chargerPartie) {
            plateau.setNouvPartie(chargerPartie);
            plateau.setTabCases(tabTypCasesCharges);
        }
        plateau.creerSpirale(info, de, joueur, decoJeu);
        //instancier le conteneur du plateau
        panelPlateau = new JPanel() {
            private static final long serialVersionUID = 1;
            private final BufferedImage buf = ImageIO.read(new File("fenetreDemarrage.jpg"));

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(buf, 0, 0, null);
            }
        };
        panelPlateau.setLayout(new GridLayout(1, 1, 0, 0));
        panelPlateau.add(plateau);
        //Les elements de la partie droite du jeu
        pChoix = new PanelMenuChoix();
        logoAp = new LogoApprentissageAnglais();
        panelEast.add(pChoix);
        panelEast.add(logoAp);

        //ajouter les panneaux à la fenetre
        add(panelPlateau);//ajouter la partie de jeu à la fenetre
        add(panelEast, BorderLayout.EAST);//La partie droite de l'affichage        
        add(panelWest, BorderLayout.WEST);//La partie gaiche du jeu
        //positionner les composants dans la fenetre
        panelWest.setBounds(0, 0, 200, getHeight());
        panelPlateau.setBounds(200, -20, 900, getHeight());
        panelEast.setBounds(1100, 0, 250, getHeight());
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//Terminer le processus lorsqu'on clique sur "Fermer"
        show();//afficher la fenetre

        //Gestion des événements de la partie droite du jeu
        /*Le bouton 'quitter' : arrêter et quitter le jeu*/
        pChoix.bQuiter.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                int resultat = JOptionPane.showConfirmDialog(null, "Voulez-vous sauvegarder la partie ?");
                if (resultat == JOptionPane.OK_OPTION) {//sortir et sauvegarder la partie
                    //on sauvegarde les information importantes de la partie
                    String rootdirectory = System.getProperty("user.dir");
                    try {
                        UIManager.setLookAndFeel("com.sun.java.swing.plaf.windows.WindowsLookAndFeel");
                    } catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException e) {
                        // handle exception
                    }
                    String cheminFichier = "";
                    Fenetre_parcours fenParcours = new Fenetre_parcours(false);
                    cheminFichier = fenParcours.chemin;
                    if (fenParcours.resultat == JOptionPane.OK_OPTION) {
                        //On récupère maintenant les données !
                        ObjectInputStream in = null;
                        ObjectOutputStream oos = null;
                        try {
                            oos = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(new File(cheminFichier))));
                            //ecrire la classe de sauvegarde dans le disque dur
                            for (int i = 0; i < 100; i++) {
                                tabTypCases[i] = Integer.parseInt(plateau.tabAleatoire.get(i).toString());
                            }
                            oos.writeObject(new Sauvegarde(joueur.nom, joueur.scoreduj, joueur.meileurScorej, numCaseCourante, tabTypCases));
                        } catch (FileNotFoundException ex) {
                        } catch (IOException ex) {
                        } finally {
                            if (oos != null) {
                                try {
                                    oos.close();
                                } catch (IOException ex) {
                                }
                            }
                        }
                        FenetrePartie.this.dispose();
                        fenParcours.dispose();
                    } else if (fenParcours.resultat == JOptionPane.NO_OPTION) {
                        fenParcours.dispose();
                    }
                } else if (resultat == JOptionPane.NO_OPTION) {//sortir sans sauvegarder
                    FenetrePartie.this.dispose();
                }
            }
        });
        /*Le bouton 'arrêter' : arrêter sans quitter le jeu*/
        pChoix.bMenu.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                try {
                    FenetreJeuTP fenJeuTP = new FenetreJeuTP();
                    fenJeuTP.fenPartie = FenetrePartie.this;
                    fenJeuTP.bNouvellePartie.setEnabled(false);
                } catch (IOException ex) {
                }
            }
        });

        /*Le bouton 'suspendre'*/
        pChoix.bSuspendre.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                switch (pChoix.bSuspendre.getText()) {
                    case "reprendre":
                        pChoix.bSuspendre.setText("suspendre");
                        de.bouton.setEnabled(!de.bouton.isEnabled());
                        for (int i = 0; i < 100; i++) {
                            ((JButton) plateau.tabAleatoire.get(i)).setEnabled(true);
                        }
                        break;
                    case "suspendre":
                        pChoix.bSuspendre.setText("reprendre");
                        de.bouton.setEnabled(!de.bouton.isEnabled());
                        for (int i = 0; i < 100; i++) {
                            ((JButton) plateau.tabAleatoire.get(i)).setEnabled(false);
                        }
                        break;
                    default:
                        throw new AssertionError();
                }
                //On récupère maintenant les données !
                ObjectInputStream ois = null;
                try {
                    ois = new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File("game.txt"))));
                } catch (IOException ex) {
                }
            }
        });
        /*Le bouton 'nouvelle partie'*/
        pChoix.bNouvellePartie.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                int resultat = JOptionPane.showConfirmDialog(null, "Voulez-vous sauvegarder la partie ?", "nouvelle partie", JOptionPane.YES_NO_OPTION);
                if (resultat == JOptionPane.OK_OPTION) {//commencer une nouvelle partie avec la sauvegarde
                    //sauvegarder la partie
                    //on sauvegarde les information importantes de la partie
                    ObjectOutputStream oos = null;
                    try {
                        oos = new ObjectOutputStream(new BufferedOutputStream(new FileOutputStream(new File("game.txt"))));
                        //ecrire la classe de sauvegarde dans le disque dur
                        for (int i = 0; i < 100; i++) {
                            tabTypCases[i] = Integer.parseInt(plateau.tabAleatoire.get(i).toString());
                        }
                        oos.writeObject(new Sauvegarde(joueur.nom, joueur.scoreduj, joueur.meileurScorej, numCaseCourante, tabTypCases));
                    } catch (FileNotFoundException ex) {
                    } catch (IOException ex) {
                    } finally {
                        if (oos != null) {
                            try {
                                oos.close();
                            } catch (IOException ex) {
                            }
                        }
                    }
                }
                //commencer une nouvelle partie
                numCaseCourante = 1;
                info.tfScoreJoueur.setText("0");
                joueur.setScoreduj(0);
                try {
                    plateau = new PlateauJeu();
                    plateau.creerSpirale(info, de, joueur, decoJeu);
                    panelPlateau.removeAll();
                    FenetrePartie.this.getContentPane().repaint();
                    panelPlateau.add(plateau);
                    panelPlateau.repaint();
                    FenetrePartie.this.getContentPane().repaint();
                } catch (DeplacementException | ReponseException ex) {
                }
            }
        });
    }

    public static JPanel setBackgroundImage(JFrame frame, final File img) throws IOException {
        JPanel panel = new JPanel() {
            private static final long serialVersionUID = 1;
            private final BufferedImage buf = ImageIO.read(img);

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(buf, 0, 0, null);
            }
        };
        panel.setBackground(Color.white);
        frame.setContentPane(panel);
        return panel;
    }
}
