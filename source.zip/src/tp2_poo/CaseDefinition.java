/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import static tp2_poo.FenetrePartie.numCaseCourante;

/**
 *
 * @author mohammed_bey
 */
public class CaseDefinition extends CaseQuestion {

    private int dernieIndiceUtilise = -1;//sauvegarder le dernier indice visité dans le tableau
    boolean acces = true;//indique si la réponse donnée par le joueur est correcte ou pas
    String tabmots[];
    private FenetreQdefinition fenDef = null;
    private String mot;

    public CaseDefinition(final InfoJeu info, DiceGame de, final JoueurTP joueur, final int num, String decoDef) throws DeplacementException, ReponseException {
        super();
        setBackground(Color.BLUE);
        setText(Integer.toString(num));
        tabmots = decoDef.split("&");
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                if (CaseDefinition.this.isEnabled() && fenDef == null) {
                    try {
                        if (num != numCaseCourante) {
                            throw new DeplacementException();
                        }
                        int random = (int) (Math.random() * (tabmots.length));
                        while (random == dernieIndiceUtilise) {
                            random = (int) (Math.random() * (tabmots.length));
                        }
                        dernieIndiceUtilise = random;//modifier la valeur du dernier indice utilisé
                        //decouper la chaine obtenue de la liste dans un tableau selon le caractere special '#'
                        final String tab[] = tabmots[random].split("#");
                        mot = tab[0];
                        fenDef = new FenetreQdefinition(mot.length(), mot);
                        fenDef.valider.addMouseListener(new MouseAdapter() {
                            @Override
                            public void mouseClicked(MouseEvent me) {
                                if (CaseDefinition.this.champVide(fenDef.saisi)) {
                                    JOptionPane.showMessageDialog(null, "Veuillez remplir tous les champs svp!");
                                } else {
                                    if (CaseDefinition.this.chamSaisi(fenDef.saisi).equals(mot)) {
                                        numCaseCourante += 4;//avancer de deux cases
                                        joueur.setScoreduj(joueur.getScoreduj() + 20);//augmenter le score du joueur                                        
                                        if (numCaseCourante > 100) {//la case où aller dépasse la derniére case du jeu
                                            numCaseCourante = 100 - (numCaseCourante - 100);
                                        }
                                        //afficher un message de congratulation
                                        JOptionPane.showMessageDialog(null, "Good answer");
                                    } else {
                                        JOptionPane.showMessageDialog(null, "Désolé ! veuillez relancer le dé pour continuer !");
                                        joueur.setScoreduj(joueur.getScoreduj() - 10);// diminuer le score du joueur
                                        acces = false;
                                    }
                                    info.tfScoreJoueur.setText(Integer.toString(joueur.getScoreduj()));
                                    fenDef.dispose();
                                }
                            }
                        });
                    } catch (DeplacementException ex) {
                    }
                } else {
                    try {
                        if (!acces) {//si la réponse donnée par le joueur est fausse
                            throw new ReponseException();
                        }
                    } catch (ReponseException ex) {
                    }
                }
            }
        });
    }

    public String chamSaisi(JTextField saisi[]) {
        String result = "";
        for (int i = 0; i < saisi.length; i++) {
            result += saisi[i].getText().toLowerCase().charAt(0);
        }
        return result;
    }

    public boolean champVide(JTextField saisi[]) {
        boolean result = false;
        for (int i = 0; i < saisi.length; i++) {
            if (saisi[i].getText().equals("")) {
                result = true;
            }
        }
        return result;
    }
}
