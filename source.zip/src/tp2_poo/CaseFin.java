/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.TreeMap;
import javax.swing.JOptionPane;
import static tp2_poo.FenetrePartie.numCaseCourante;

/**
 *
 * @author mohammed_bey
 */
public class CaseFin extends CaseJeu {

    ArrayList<String> listMeiSc = new ArrayList();
    TreeMap<Integer, String> tm = new TreeMap<Integer, String>();
    private boolean finPartie = false;

    public CaseFin(final InfoJeu info, final DiceGame de, final JoueurTP joueur) {
        super();
        setBackground(Color.BLACK);
        setText(Integer.toString(100));
        addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                if (CaseFin.this.isEnabled()) {
                    try {
                        if (numCaseCourante != 100) {
                            throw new DeplacementException();
                        }
                        if (finPartie) {
                            throw new FinPartieException();
                        }
                        finPartie = true;
                        de.bouton.setEnabled(false);
                        info.tfCaseActuelle.setText(Integer.toString(numCaseCourante));
                        JOptionPane.showMessageDialog(null, "Bravo ! vous avez gagné la partie");
                        if (joueur.meileurScorej < joueur.scoreduj) {
                            joueur.meileurScorej = joueur.scoreduj;
                        }
                        BufferedReader readerMeilSc = null;
                        BufferedWriter writerMeiSc = null;
                        String meilleureScores = "";
                        try {
                            readerMeilSc = new BufferedReader(new FileReader("MeilleursScores.txt"));//lecture du fichier des meilleurs scores du jeu
                            String line = "";
                            while ((line = readerMeilSc.readLine()) != null) {
                                String tab[] = line.split("#");
                                tm.put(Integer.parseInt(tab[0]), tab[1]);
                            }
                            tm.put(joueur.scoreduj, joueur.nom);
                            //vider la liste
                            listMeiSc.clear();
                            //remplir la liste à partir du TreeMap
                            for (Integer key : tm.keySet()) {
                                listMeiSc.add(Integer.toString(key) + "#" + tm.get(key));
                            }
                            readerMeilSc.close();
                            //Reactualiser le fichier des meilleurs scores
                            writerMeiSc = new BufferedWriter(new FileWriter("MeilleursScores.txt"));
                            if (listMeiSc.size() <= 10) {//le fichier contient moins de 10 meilleurs scores
                                for (int i = listMeiSc.size() - 1; i >= 0; i--) {
                                    writerMeiSc.write(listMeiSc.get(i) + "\n");
                                    meilleureScores += listMeiSc.get(i) + "\n";
                                }
                            } else {//le nombre des meilleurs scores est superieur à 10 donc on choisit juste les 10 meilleurs
                                for (int i = listMeiSc.size() - 1; i >= (listMeiSc.size() - 10); i--) {
                                    writerMeiSc.write(listMeiSc.get(i) + "\n");
                                    meilleureScores += listMeiSc.get(i) + "\n";
                                }
                            }
                        } catch (FileNotFoundException ex) {
                        } catch (IOException ex) {
                        } finally {
                            if (readerMeilSc != null) {
                                try {
                                    readerMeilSc.close();
                                } catch (IOException ex) {
                                }
                            }
                            if (writerMeiSc != null) {
                                try {
                                    writerMeiSc.close();
                                } catch (IOException ex) {
                                }
                            }
                        }
                        try {
                            FenetreFin fenFin = new FenetreFin(joueur, info, meilleureScores);
                        } catch (IOException ex) {
                        }
                    } catch (FinPartieException | DeplacementException ex) {
                    }
                }
            }
        });
    }

    //retourner le type de la case
    @Override
    public String toString() {
        return "1";
    }
}
