/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.io.IOException;

/**
 *
 * @author mohammed_bey
 */
public class Tp2_poo {

    /**
     * @param args the command line arguments
     * @throws java.io.IOException
     */
    public static void main(String[] args) throws IOException {
//         TODO code application logic here
//        FenetrePartie fen = new FenetrePartie();
        FenetreJeuTP fen = new FenetreJeuTP();
//        FenetreQdefinition fen = new FenetreQdefinition(16, "We use it to eat the soop");
//        Fenetre_parcours fen = new Fenetre_parcours();
//        FenetreQimage fen = new FenetreQimage();
//        FenetreNomUtilisateur fen = new FenetreNomUtilisateur();
    }
}
