/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import javax.swing.JLabel;
import javax.swing.JPanel;

/**
 *
 * @author mohammed_bey
 */
public class AffichageInfo extends JPanel {

    JLabel nomJoueur, score, numCase;

    public AffichageInfo() {

    }

}
