/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.JPanel;

/**
 *
 * @author mohammed_bey
 */
public class LogoApprentissageAnglais extends JPanel {

    private static final long serialVersionUID = 1;
    private File img = new File("logoJeu.jpg");

    public LogoApprentissageAnglais() throws IOException {
        setLayout(null);
        setBackground(Color.WHITE);
        JPanel panel = new JPanel() {
            private static final long serialVersionUID = 1;
            private final BufferedImage buf = ImageIO.read(img);

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(buf, 0, 0, null);
            }
        };
        panel.setBackground(Color.WHITE);
       panel.setSize(300, 500);
        add(panel);
    }
}
