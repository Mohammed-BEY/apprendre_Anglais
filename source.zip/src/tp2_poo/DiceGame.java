/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.Timer;
import static tp2_poo.FenetrePartie.numCaseCourante;
import javax.swing.JOptionPane;

/**
 *
 * @author mohammed_bey
 */
public class DiceGame extends JPanel implements ActionListener {

    JButton bouton = new JButton("lancer les dés");
    JLabel labDe1 = new JLabel(),
            labDe2 = new JLabel();
    Timer timer1, timer2;
    boolean b = true;   // for starting and stoping animation
    long startTime;
    InfoJeu info;

    /**
     *
     */
    public DiceGame() {
        setPreferredSize(new Dimension(68 * 2 + 20, 68 + 20 + 25));
        setLayout(new FlowLayout(FlowLayout.CENTER, 0, 20));
        setBackground(Color.WHITE);
        labDe1.setIcon(new ImageIcon("Des/1.png"));
        labDe2.setIcon(new ImageIcon("Des/6.png"));
        JPanel panelDes = new JPanel(new FlowLayout(FlowLayout.CENTER, 30, 0));
        panelDes.setBackground(Color.WHITE);
        panelDes.add(labDe1);
        panelDes.add(labDe2);
        //ajouter un ecouteur pour le bouton
        bouton.addActionListener(this);
        //ajouter les composants au Panel     
        add(panelDes);
        add(bouton);
        //
        bouton.setBackground(Color.red);
    }

    @Override
    public void actionPerformed(ActionEvent v) {
        int random1 = (int) (Math.random() * (7 - 1)) + 1, random2 = (int) (Math.random() * (7 - 1)) + 1;
        //changer l'image1 selon le resultat du lancemet du dé1
        labDe1.setIcon(new ImageIcon("Des/" + Integer.toString(random1) + ".png"));
        //changer l'image2 selon le resultat du lancemet du dé2
        labDe2.setIcon(new ImageIcon("Des/" + Integer.toString(random2) + ".png"));

        numCaseCourante += random1 + random2;
        if (numCaseCourante > 100) {//la case où aller dépasse la derniére case du jeu
            numCaseCourante = 100 - (numCaseCourante - 100);
        }
        //mettre à jour l'affichage
        info.tfCaseActuelle.setText(Integer.toString(numCaseCourante));
        JOptionPane.showConfirmDialog(null, "il faut aller vers la case : " + Integer.toString(numCaseCourante), "reultat du lancement des dés", JOptionPane.CLOSED_OPTION);
        bouton.setEnabled(false);
    }
}
