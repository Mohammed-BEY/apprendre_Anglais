/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tp2_poo;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.ObjectInputStream;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import static tp2_poo.FenetrePartie.numCaseCourante;

/**
 *
 * @author mohammed_bey
 */
public class FenetreJeuTP extends JFrame {

    JButton bNouvellePartie, bContinuer, bMeilleurScores, bPropos, bQuitter;

    //retourner le tableau des images
    String decoJeu;//contient les deux fichiers du dictionnaire
    String meilleureScores;//contient la chaine des meilleurs scores du jeu
    int tabtypCases[];
    FenetrePartie fenPartie = null;

    public FenetreJeuTP() throws IOException {
        setTitle("Jeu de l'oie");
        setSize(300, 500);
        setResizable(false);
        //centrer la fenetre
        this.setLocationRelativeTo(null);
        /**
         * variable de classe contenant l'image à afficher en fond
         */
        bNouvellePartie = new JButton("nouvelle partie");
        bContinuer = new JButton("continuer");
        bMeilleurScores = new JButton("meilleurs scores");
        bPropos = new JButton("à propos");
        bQuitter = new JButton("quitter");
        JPanel panel = setBackgroundImage(this, new File("fenetreDemarrage.jpg"));
        panel.setLayout(null);//enlever les layouts
        //ajouter les composants au conteneur
        panel.add(bNouvellePartie);
        panel.add(bContinuer);
        panel.add(bMeilleurScores);
        panel.add(bPropos);
        panel.add(bQuitter);
        //Positionner les boutons dans le conteneur
        bNouvellePartie.setBounds(70, 50, 150, 33);
        bContinuer.setBounds(70, 130, 150, 33);
        bMeilleurScores.setBounds(70, 210, 150, 33);
        bPropos.setBounds(70, 290, 150, 33);
        bQuitter.setBounds(70, 370, 150, 33);
        //mettre le conteneur construit comme le conteneur de la fenetre
        setContentPane(panel);
        //Charger les fichier du dictionnaire (Definitions et Images)
        //ainsi que le fichier des meilleurs scores
        BufferedReader readerDef = null, readerImage = null;
        BufferedInputStream readerMeilSc = null;
        try {
            String line = "";
            int c;
            readerMeilSc = new BufferedInputStream(new FileInputStream("MeilleursScores.txt"));//lecture du fichier des meilleurs scores du jeu
            readerDef = new BufferedReader(new FileReader("DecoDefinitions.txt"));//lecture du fichier des definitions            
            readerImage = new BufferedReader(new FileReader("DecoImages.txt"));//lecture du fichier des images
            decoJeu = "";
            while ((line = readerDef.readLine()) != null) {
                decoJeu += line + "&";
            }
            decoJeu += ";";
            while ((line = readerImage.readLine()) != null) {
                decoJeu += line + "&";
            }

            meilleureScores = "";
            while ((c = readerMeilSc.read()) != -1) {
                meilleureScores += (char) c;
            }
        } catch (IOException e) {
            e.getMessage();
        } finally {
            if (readerDef != null) {
                readerDef.close();
            }
            if (readerImage != null) {
                readerImage.close();
            }
            if (readerMeilSc != null) {
                readerMeilSc.close();
            }
        }
        //extraire le champion du jeu du fichier des meilleurs scores
        String tab[] = meilleureScores.split("\n");
        final String champion[] = tab[0].split("#");
        /**
         * ***Gestion des evenements**********
         */
        //quitter le jeu
        bQuitter.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                FenetreJeuTP.this.dispose();
            }
        });
        //lancer une nouvelle partie
        bNouvellePartie.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                if (FenetreJeuTP.this.bNouvellePartie.isEnabled()) {
                    final FenetreNomUtilisateur username = new FenetreNomUtilisateur();
                    //Gestion des evenements
                    username.bValider.addMouseListener(new MouseAdapter() {
                        @Override
                        public void mouseClicked(MouseEvent me) {
                            String nomJoueur = username.userNamme.getText();
                            try {//tester si le champ introduit par l'utlisateur ne contient pas que des nombres
                                Double.parseDouble(username.userNamme.getText());
                                JOptionPane.showMessageDialog(rootPane, "Votre nom doit contenir au moins un caractére alphabétique !");
                            } catch (NumberFormatException nf) {
                                if (!username.userNamme.getText().equals("")) {//verifier si le champ de saisie n'est pas vide                                
                                    try {
                                        fenPartie = new FenetrePartie(username.userNamme.getText(), decoJeu, champion, false, tabtypCases);
                                    } catch (IOException ex) {
                                    } catch (DeplacementException | ReponseException ex) {
                                        ex.getMessage();
                                    }
                                    username.dispose();
                                    FenetreJeuTP.this.dispose();
                                } else {
                                    JOptionPane.showMessageDialog(null, "Veuillez saisir votre nom");
                                }
                            }
                        }
                    });
                }
            }
        });
        //continuer le jeu de la derniere fois
        bContinuer.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                String cheminFichier = "";
                Fenetre_parcours fenParcours = new Fenetre_parcours(true);
                cheminFichier = fenParcours.chemin;
                if (fenParcours.resultat == JOptionPane.OK_OPTION) {
                    //On récupère maintenant les données !
                    ObjectInputStream in = null;
                    try {
                        //Récupération des objets stockés
                        in = new ObjectInputStream(new BufferedInputStream(new FileInputStream(new File(cheminFichier))));
                        Sauvegarde partieChargee = (Sauvegarde) in.readObject();
                        String nomJoueur = partieChargee.nomJoueur;
                        //la case où le jeu s'est arrêté
                        numCaseCourante = partieChargee.numCaseActuelle;
                        //le tableau des types des cases
                        tabtypCases = partieChargee.tabtypCases;
                        //recréer la partie pour continuer le jeu
                        if (fenPartie != null) {
                            fenPartie.dispose();
                        }
                        fenPartie = new FenetrePartie(nomJoueur, decoJeu, champion, true, tabtypCases);
                        fenPartie.getJoueur().scoreduj = partieChargee.scoreJoueur;
                        //mettre à jour l'affichage
                        fenPartie.info.tfScoreJoueur.setText(Integer.toString(partieChargee.scoreJoueur));
                        fenPartie.info.tfCaseActuelle.setText(Integer.toString(numCaseCourante));
                    } catch (IOException | ClassNotFoundException ex) {
                    } catch (DeplacementException | ReponseException ex) {
                    } finally {
                        if (in != null) {
                            try {
                                in.close();
                            } catch (IOException ex) {
                            }
                        }
                    }
                    fenParcours.dispose();
                    FenetreJeuTP.this.dispose();
                } else if (fenParcours.resultat == JOptionPane.NO_OPTION) {
                    fenParcours.dispose();
                }
            }
        });
        //afficher les meilleurs scores
        bMeilleurScores.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                try {
                    FenetreMeilleuresScores fenMeilleuresScores = new FenetreMeilleuresScores(meilleureScores);
                } catch (IOException ex) {
                }
            }
        });
        //afficher les informaitons concernant le jeu
        bPropos.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent me) {
                FenetreApropos fenApropos = new FenetreApropos();
            }
        });

        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);//Terminer le processus lorsqu'on clique sur "Fermer"
        show();
    }

    public static JPanel setBackgroundImage(JFrame frame, final File img) throws IOException {
        JPanel panel = new JPanel() {
            private static final long serialVersionUID = 1;
            private final BufferedImage buf = ImageIO.read(img);

            @Override
            protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                g.drawImage(buf, 0, 0, null);
            }
        };
        panel.setBackground(Color.white);
        frame.setContentPane(panel);
        return panel;
    }
}
