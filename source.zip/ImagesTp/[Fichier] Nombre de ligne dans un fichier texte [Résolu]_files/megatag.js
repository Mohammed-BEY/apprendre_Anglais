(function(global) {

	var w = getMegatagWindow(),
		_defaults = {
			url: ('https:'==w.document.location.protocol?'https://secure':'http://ib')+'.adnxs.com',
			mtjBase: '/mtj',
			ttjBase: '/ttj',
			ttBase: '/tt',
			bounceBase: '/bounce'
		},
		checker,
		_processQueue = function() {
			if (global.window._anq && global.window._anq.length > 0) {
				for (var i = 0; i < global.window._anq.length; i++) {
					if (typeof global.window._anq[i].called === 'undefined') {
						global.window._anq[i].cmd();
						global.window._anq[i].called = true;
					}
				}
			}
			cleanUpCmds();
		};

	getMegatagWindow().adnxs = !!getMegatagWindow().adnxs ? getMegatagWindow().adnxs : {};
	adnxs = getMegatagWindow().adnxs;
	adnxs.richmedia = adnxs.richmedia || {setSize: function() {}};
	adnxs.megatag = adnxs.megatag || {};
	adnxs.megatag.isCleanupSet = adnxs.megatag.isCleanupSet || false;
	adnxs.megatag.errors = adnxs.megatag.errors || [];
	adnxs.megatag.debug = false;
	adnxs.megatag.requests = adnxs.megatag.requests || [];

	adnxs.megatag.hasOwnProperty = function(o, p) {
		return (o.hasOwnProperty ? o.hasOwnProperty(p) : (!(typeof o[p] === 'undefined') && o.constructor.prototype[p] !== o[p]));
	}

	if (!adnxs.megatag.load) {
		adnxs.megatag.load = function(rawParams) {
			_load(rawParams);
		}
	}

	if (!adnxs.megatag.populateIframes) {
		adnxs.megatag.populateIframes = function(requestId) {
			populateIframes(requestId);
		}
	}

	if (!adnxs.megatag.forceAdCall) {
		adnxs.megatag.forceAdCall = adnxs.megatag.forceLoad = function(oParams) {
			if (!isAutoLoad()) {
				var params = oParams || {};
				var idsToLoad = [];

				if (params.adnxsId) {
					idsToLoad.push(params.adnxsId);
				} else {
					for (var i in adnxs.megatag.requests) {
						if (adnxs.megatag.hasOwnProperty(adnxs.megatag.requests, i)) {
							idsToLoad.push(i);
						}
					}
				}

				for (var i=0; i < idsToLoad.length; i++) {
					var request = adnxs.megatag.requests[idsToLoad[i]];
					if (request.placementCount && request.placementsLoaded !== request.placementCount) {
						logError('Placement count does not match the number of placements loaded.');
					}

					try {
						if (!window.opera) {
							writeMtjIframe({adnxsId: idsToLoad[i]});
						}
					} catch (err) {
						logError(err.message);
					}
				}

			}
		}
	}

	if (!adnxs.megatag.refreshAds) {
		adnxs.megatag.refreshAds = function(oParams) {
			var adnxsId = (oParams ? oParams.adnxsId || null : null);
			_refreshAds(adnxsId);
		}
	}

	function _load(inputParams) {
		var params = renameParams(inputParams || window.adnxsRoadblockparams),
			tagId = '';

		params.adnxsId = params.adnxsId || window.adnxsId;

		if (params.debug) {
			adnxs.megatag.debug = params.debug;
		}

		if (!params.size) {
			logError('Size parameter not specified for ad spot. No ad will be shown for this spot.');
			return;
		}

		try {
			tagId = updateTags(params);

			if (adnxs.megatag.requests[params.adnxsId] && adnxs.megatag.requests[params.adnxsId].mtjCalled === true &&
					!adnxs.megatag.requests[params.adnxsId].tags[tagId].mtjCalled) {
				logError('A placement was loaded after mtj call was started. '
					+ 'It is possible that there are more placements on the page than the placement count indicates');
			}

			writeMarker(params, tagId);
			if (window.opera) {
				writeTtIframe(params);
			} else {
				writeIframe(params, tagId);
			}

			if (adnxs.megatag.requests[params.adnxsId].isOnloadSet === false && isAutoLoad()) {
				setOnload(params);
			}
		} catch (err) {
			logError(err.message);
			writeTtIframe(params);
		}

	}

	function _refreshAds(requestId) {
		var idsToRefresh = [];
		if (requestId) {
			idsToRefresh.push(requestId);
		} else { // get all the ids
			for (var i in adnxs.megatag.requests) {
				if (adnxs.megatag.hasOwnProperty(adnxs.megatag.requests, i)) {
					idsToRefresh.push(i);
				}
			}
		}

		for (var i=0; i < idsToRefresh.length; i++) {
			var id = idsToRefresh[i];
			for (var t in adnxs.megatag.requests[id].tags) {
				adnxs.megatag.requests[id].tags[t].mtjCalled = false;
				adnxs.megatag.requests[id].tags[t].iframesPopulated = false;
			}

			try {
				if (navigator.userAgent.indexOf('MSIE') !== -1) {
					doIEMtjCall(
						{adnxsId: id, mtjUri: adnxs.megatag.requests[id].mtjUri},
						adnxs.megatag.requests[id].mtjIframe
					);
				} else {
					doMtjCall(
						{adnxsId: id, mtjUri: adnxs.megatag.requests[id].mtjUri},
						adnxs.megatag.requests[id].mtjIframe
					);
				}
			} catch (err) {
				logError(err.message);
			}

		}
	}

	function serializeParams(rawParams) {
		var params = "";

		for (var i in rawParams) {
			if (adnxs.megatag.hasOwnProperty(rawParams, i)) {
				params += renameParam(i) + '=' + encodeURIComponent(rawParams[i]) + '&';
			}
		}
		params = params.substring(0, params.length-1);

		return params;
	}

	function renameParams(rawParams) {
		var output = {};
		for (var i in rawParams) {
			if (adnxs.megatag.hasOwnProperty(rawParams, i)) {
				output[renameParam(i)] = rawParams[i];
			}
		}
		return output;
	}

	function renameParam(key) {
		switch (key) {
			case 'promoSizes':
				return 'promo_sizes';
			default:
				return key;
		}
	}

	function getScriptParams(serializedParams) {
		var params = {},
			rawParams = serializedParams,
			pair,
			regEx = /([^&=]+)=?([^&]*)/g,
			convertPlusToSpace = function (s) { return decodeURIComponent(s.replace(/\+/g, " ")); };

		while (pair = regEx.exec(rawParams)) {
			params[pair[1]] = convertPlusToSpace(pair[2]);
		}

		return params;
	}

	function getMegatagWindow() {
		if (w) {
			try {
				var documentCheck = w.document.a;
			} catch (err){
				w = detectMegatagWindow();
			}
		} else {
			w = detectMegatagWindow();
		}

		return w;
	}

	function detectMegatagWindow() {
		var candidateWindow,
			currentWindow,
			parentFrameSet = false;

		if (typeof adnxsMegatagWindow !== 'undefined') {
			candidateWindow = adnxsMegatagWindow;
		} else {
			try {
				var currentWindow = global.window;

				do {
					if (currentWindow.parent.document.getElementsByTagName('frameset').length > 0) {
						parentFrameSet = true;
						break;
					}
					currentWindow = currentWindow.parent;
				} while (currentWindow.document !== currentWindow.parent.document);

				if (parentFrameSet) {
					var parentFrames = currentWindow.parent.document.getElementsByTagName('frame');

					for (var i=0; i < parentFrames.length; i++) {
						if (parentFrames[i].contentWindow.document === currentWindow.document) {
							currentWindow = parentFrames[i].contentWindow;
							break;
						}
					}
				}

				candidateWindow = currentWindow;

			} catch (err) {
				candidateWindow = global.window;
			}

		}

		return candidateWindow;
	}

	function updateTags(params) {
		adnxs.megatag.requests[params.adnxsId] = adnxs.megatag.requests[params.adnxsId] || {};
		adnxs.megatag.requests[params.adnxsId].tags = adnxs.megatag.requests[params.adnxsId].tags || {};
		adnxs.megatag.requests[params.adnxsId].iframes = adnxs.megatag.requests[params.adnxsId].iframes || {};
		adnxs.megatag.requests[params.adnxsId].mtjCalled = adnxs.megatag.requests[params.adnxsId].mtjCalled || false;
		adnxs.megatag.requests[params.adnxsId].placementsLoaded = adnxs.megatag.requests[params.adnxsId].placementsLoaded || 0;
		adnxs.megatag.requests[params.adnxsId].isOnloadSet = false;
		adnxs.megatag.requests[params.adnxsId].suppressBaseTag = adnxs.megatag.requests[params.adnxsId].isOnloadSet || params.suppressBaseTag || false;

		var tagId = generateTagId(params.elementId, params.adnxsId);

		checkTags(params);
		adnxs.megatag.requests[params.adnxsId].placementCount = getPlacementCount(params);

		adnxs.megatag.requests[params.adnxsId].tags[tagId] = params;
		adnxs.megatag.requests[params.adnxsId].tags[tagId].subscriptions = params.subscriptions || {};
		adnxs.megatag.requests[params.adnxsId].tags[tagId].mtjCalled = adnxs.megatag.requests[params.adnxsId].tags[tagId].mtjCalled || false;
		adnxs.megatag.requests[params.adnxsId].tags[tagId].iframesPopulated = adnxs.megatag.requests[params.adnxsId].tags[tagId].iframesPopulated || false;

		adnxs.megatag.requests[params.adnxsId].placementsLoaded++;
		if (typeof adnxsManualLoad === 'undefined' && params.manualLoad) {
			adnxs.megatag.manualLoad = params.manualLoad;
		} else if (typeof adnxsManualLoad !== 'undefined') {
			adnxs.megatag.manualLoad = adnxsManualLoad;
		} else {
			adnxs.megatag.manualLoad = false;
		}

		if (adnxs.megatag.requests[params.adnxsId].placementsLoaded === 1*adnxs.megatag.requests[params.adnxsId].placementCount &&
			isAutoLoad() && params.placementCount != 1) {
			try {
				if (!window.opera) {
					writeMtjIframe(params);
				}
			} catch (err) {
				logError(err.message);
			}
		}

		adnxs.megatag.requests[params.adnxsId].iframes[tagId] = {
			params: params
		};

		return tagId;
	}

	function generateTagId(elementId, requestId) {
		var random = Math.random() * 1000,
			i = 0;

		if (elementId) {return elementId + '_' + random;}

		while (adnxs.megatag.requests[requestId].tags['adnxs_tag_'+random]) { i++; }

		return 'adnxs_tag_' + random;
	}

	function writeMarker(params, tagId) {
		var writeWindow = params.frameWindow || global.window || window;

		try {
			while (writeWindow.document !== writeWindow.parent.document) {
				writeWindow.adnxsMarker = tagId;
				writeWindow = writeWindow.parent;
			}
		} catch (err) {
			logError('A parent window could not be marked.');
		}

	}

	function writeIframe(params, tagId) {
		var iframe = getMegatagWindow().document.createElement('iframe'),
			div = getMegatagWindow().document.createElement('div'),
			placeholder = getMegatagWindow().document.createElement('div'),
			scripts = (params.frameWindow || global.window).document.getElementsByTagName('script'),
			thisScript = scripts[scripts.length-1];

		params.rawSizes = params.size.toLowerCase().split('x');
		if (hasInitialSize(params)) {
			iframe.width = params.rawSizes[0];
			iframe.height = params.rawSizes[1];
		} else {
			iframe.width = 0;
			iframe.height = 0;
			placeholder.style.display = 'none';
		}

		placeholder.id = 'ph_'+tagId;
		placeholder.style.width = iframe.width+'px';
		placeholder.style.height = iframe.height+'px';

		div.id = 'div_'+tagId;
		div.style.display = 'none';

		iframe.id = tagId;
		iframe.name = tagId;
		iframe.frameBorder = "0";
		iframe.marginWidth = "0";
		iframe.marginHeight = "0";
		iframe.scrolling="no";
		iframe.setAttribute('border', '0');
		iframe.setAttribute('allowtransparency', "true");
		iframe.style.display = 'none';
		iframe.style.visibility = 'hidden';

		adnxs.megatag.requests[params.adnxsId].iframes[tagId].scriptEl = thisScript;
		adnxs.megatag.requests[params.adnxsId].iframes[tagId].frameEl = iframe;
		adnxs.megatag.requests[params.adnxsId].iframes[tagId].divEl = div;
		adnxs.megatag.requests[params.adnxsId].iframes[tagId].placeholderEl = placeholder;
		adnxs.megatag.requests[params.adnxsId].iframes[tagId].params = params;

		insertPlaceholder(adnxs.megatag.requests[params.adnxsId].iframes[tagId], tagId);
	}

	function getTopWindowUrl() {
		var w = getMegatagWindow();
		try {
			return w.top.location.href;
		} catch (e) {
			return w.location.href;
		}
	}

	function writeMtjIframe(params) {
		var tagid;
		for (var t in adnxs.megatag.requests[params.adnxsId].tags) {
			if (t.indexOf(params.elementId) === 0) {
				tagid = t;
				break;
			}
		}

		adnxs.megatag.requests[params.adnxsId].mtjCalled = true;

		if ((!adnxs.megatag.requests[params.adnxsId].tags[tagid] || adnxs.megatag.requests[params.adnxsId].tags[tagid].mtjCalled === false) && !params.mtjCalled) {

			var iframe = getMegatagWindow().document.createElement('iframe'),
				randomizer = Math.random() * 1000,
				div = getMegatagWindow().document.createElement('div');

			params.mtjUri = getMtjUri(params, true);

			adnxs.megatag.requests[params.adnxsId].mtjUri = getMtjUri(params);

			iframe.id = 'mtjif_' + randomizer;
			iframe.name = 'mtjif_ ' + randomizer;
			iframe.style.display = "none";
			div.style.display = 'none';

			adnxs.megatag.requests[params.adnxsId].mtjIframe = iframe;

			if (getMegatagWindow().document.body) {
				try {
					div.appendChild(iframe);

					if (navigator.userAgent.indexOf('MSIE') !== -1) {
						if (getMegatagWindow().document.body.childNodes && getMegatagWindow().document.body.childNodes.length > 0) {
							getMegatagWindow().document.body.insertBefore(div, getMegatagWindow().document.body.childNodes[0]);
							doIEMtjCall(params, iframe);
						}
					} else {
						getMegatagWindow().document.body.appendChild(div);
						doMtjCall(params, iframe);
					}

				} catch (err) {
					handleMtjError(err, params, iframe);
				}
			}

		}
	}

	function doIEMtjCall(params, iframe) {
		normalizeDomain(iframe);
		removeBaseTags(params.adnxsId, params.suppressBaseTag);
		iframe.contentWindow.contents = '<!DOCTYPE html><head><title></title>' +
			'<meta http-equiv="content-type" content="text/html; charset=UTF-8">' +
			'<script type="text/javascript" src="'+params.mtjUri+'"><\/script>' +
			'<script>try{if (document.domain !== "'+getMegatagWindow().document.domain+'") {' +
			'document.domain = "'+getMegatagWindow().document.domain+'";}' +
			'var parent_check = window.parent.document.domain;} catch (e) {'+
			'document.domain = "'+getMegatagWindow().document.domain+'";}' +
			'try{if (window.adnxs_ads) {window.parent.adnxs_ads = window.adnxs_ads || {};' +
			'window.parent.adnxs_backup_tags = window.adnxs_backup_tags || {};' +
			'window.parent.adnxs.megatag.populateIframes("'+params.adnxsId+'");}' +
			'} catch (e) {}<\/script>' +
			'</head><body></body></html>';
		iframe.src = 'about:blank';
		iframe.src = 'javascript:window["contents"];';
	}

	function doMtjCall(params, iframe) {
		normalizeDomain(iframe);
		var contents = '<!DOCTYPE html><html><head><title></title>\
				<meta http-equiv="content-type" content="text/html; charset=UTF-8">\
				<scr'+'ipt src="'+getBlankUrl()+'"></scr'+'ipt>\
				<scr'+'ipt src="'+params.mtjUri+'"></scr'+'ipt></head>\
				<body><scr'+'ipt>try{if (window.adnxs_ads) {\
				window.parent.adnxs_ads = window.adnxs_ads || {};\
				window.parent.adnxs_backup_tags = window.adnxs_backup_tags || {};\
				window.parent.adnxs.megatag.populateIframes("'+params.adnxsId+'");}} catch(e) {}</scr'+'ipt>\
				</body></html>';
		iframe.contentWindow.document.open('text/html', 'replace');
		iframe.contentWindow.document.write(contents);
		iframe.contentWindow.document.close();
	}

	function handleMtjError(err, params, iframe) {
		var caseInsensitiveMessage = err.message.toLowerCase();
		if (caseInsensitiveMessage.indexOf('permission denied') > -1
			|| caseInsensitiveMessage.indexOf('access is denied') > -1) {
			logError('Access denied to mtj iframe window, making script call', 'WARN');

			var script = document.createElement('script');
			script.type = 'text/javascript';
			script.src = params.mtjUri;

			if (typeof script.onreadystatechange !== 'undefined') {
				script.onreadystatechange = function() {
					if (this.readyState === 'complete' || this.readyState === 'loaded') {
						adnxs.megatag.populateIframes(params.adnxsId);
					}
				}
			} else {
				script.onload = function() {
					adnxs.megatag.populateIframes(params.adnxsId);
				}
			}

			getMegatagWindow().document.body.appendChild(script);

		} else {
			logError(err);
			throw err;
		}
	}

	function removeBaseTags(id, suppressFlag) {
		var baseTags = getMegatagWindow().document.getElementsByTagName('base');
		if (baseTags && baseTags.length > 0) {

			if (suppressFlag && suppressFlag === true) {
				logError(baseTags.length + ' <base> tag(s) were discovered on the publisher page and were stripped before ad population. They will be replaced when ads are done populating.', 'WARNING');
				adnxs.megatag.requests[id].discoveredBaseTags = [];
				for (var i = 0; i < baseTags.length; i++) {
					adnxs.megatag.requests[id].discoveredBaseTags.push(baseTags[i].parentNode.removeChild(baseTags[i]));
				}
			} else {
				logError(baseTags.length + ' <base> tag(s) were discovered on the publisher page preventing ads to load in IE. To enable ad loading in IE add the suppressBaseTag: true option to your tags.');
			}

		}
	}

	function insertIframe(frameObj, tagId) {

		var params = frameObj.params;
		var thisScript = frameObj.scriptEl;
		var placeholderEl = getMegatagWindow().document.getElementById(frameObj.placeholderEl.id);

		if (!placeholderEl){
			placeholderEl = frameObj.placeholderEl;
		}

		var el = placeholderEl.parentNode;

		if (el) {
			frameObj.divEl.appendChild(frameObj.frameEl);
			el.insertBefore(frameObj.divEl, placeholderEl);
			placeholderEl.style.display = 'none';

			return el;
		}

		throw new Error('Failed to insert iframe');
	}

	function insertPlaceholder(frameObj, tagId) {
		var params = frameObj.params;
		var thisScript = frameObj.scriptEl;
		var tokenIframe = document.createElement('iframe');
		tokenIframe.width = frameObj.placeholderEl.style.width;
		tokenIframe.height = frameObj.placeholderEl.style.height;
		tokenIframe.frameBorder = "0";
		tokenIframe.marginWidth = "0";
		tokenIframe.marginHeight = "0";
		tokenIframe.scrolling="no";
		tokenIframe.setAttribute('border', '0');
		tokenIframe.setAttribute('allowtransparency', "true");
		tokenIframe.style.visibility = 'hidden';

		if (getMegatagWindow().document === (params.frameWindow || global.window).document) {
			var el = (params && params.targetId && getMegatagWindow().document.getElementById(params.targetId))
				? getMegatagWindow().document.getElementById(params.targetId) : thisScript;

			frameObj.placeholderEl.appendChild(tokenIframe);
			el.parentNode.insertBefore(frameObj.placeholderEl, el);
			return el;
		} else {
			var el;
			if (params && params.targetId){
				el = getMegatagWindow().document.getElementById(params.targetId);

				if (!el && params.frameWindow && params.frameWindow.document){
					el = params.frameWindow.document.getElementById(params.targetId);
				} 
			}

			if (!el){
				el = getTopLevelIframe((params || {}).frameWindow || global.window || window, tagId);
			}

			if (el) {
				frameObj.placeholderEl.appendChild(tokenIframe);
				el.parentNode.appendChild(frameObj.placeholderEl);
				el.style.display = 'none';
				return el;
			}
		}

		throw new Error('Failed to insert placeholder');
	}

	function getTopLevelIframe(currentWindow, tagId) {
		var parent = currentWindow.parent,
			parentIframes = parent.document.getElementsByTagName('iframe');

		for (var i=0; i < parentIframes.length; i++) {
			var thisWindow = parentIframes[i].contentWindow;

			try {
				var a = thisWindow.adnxsMarker;
			}catch (err) {continue;}

			if (thisWindow.adnxsMarker && thisWindow.adnxsMarker === tagId) {
				while (thisWindow.parent.document !== thisWindow.parent.parent.document) {
					thisWindow = thisWindow.parent;
				}
				var topLevelFrames = thisWindow.parent.document.getElementsByTagName('iframe');
				if (topLevelFrames.length > 0) {
					for (var j=0; j < topLevelFrames.length; j++) {
						var upperWindow = topLevelFrames[j].contentWindow;

						try {
							var a = upperWindow.adnxsMarker;
						}catch (err) {continue;}

						if (tagId === upperWindow.adnxsMarker) {
							return topLevelFrames[j];
						}
					}
				} else {
					var thisWindowFrames = thisWindow.document.getElementsByTagName('iframe');
					for (var j=0; j < thisWindowFrames.length; j++) {
						var upperWindow = topLevelFrames[j].contentWindow;

						try {
							var a = upperWindow.adnxsMarker;
						}catch (err) {continue;}

						if (tagId === upperWindow.adnxsMarker) {
							return thisWindowFrames[j];
						}
					}
				}
			}
		}

		if (parent.document === parent.parent.document) {
			return null;
		} else {
			return getTopLevelIframe(parent.parent, tagId);
		}

	}

	function hasInitialSize(params) {
		if (params && params.setIframeSize && params.setIframeSize === true ||
			(params.setIframeSize && params.setIframeSize === 'true') ||
			(typeof adnxsSetIframeSize !== 'undefined' && adnxsSetIframeSize === true)) {

			return true;
		}
		return false;
	}

	function getPlacementCount(params) {
		checkCount(params);

		if (typeof adnxsPlacementCount !== 'undefined') {
			return adnxsPlacementCount;
		} else {
			return adnxs.megatag.requests[params.adnxsId].placementCount || params.placementCount;
		}
	}

	function getDomReadyConfig() {
		if (typeof adnxsDomReady !== 'undefined') {
			return adnxsDomReady === true;
		}
		return false;
	}

	function getBaseUrl() {
		return (typeof adnxs_url !== 'undefined' ? adnxs_url : _defaults.url);
	}

	function getMtjEndpoint() {
		return (typeof adnxs_mtj !== 'undefined' ? adnxs_mtj : _defaults.mtjBase);
	}

	function getTtjEndpoint() {
		return (typeof adnxs_ttj !== 'undefined' ? adnxs_ttj : _defaults.ttjBase);
	}

	function getTtEndpoint() {
		return (typeof adnxs_tt !== 'undefined' ? adnxs_tt : _defaults.ttBase);
	}

	function getBounceEndpoint() {
		return _defaults.bounceBase;
	}

	function getBlankUrl() {
		return (w.document.location.protocol === 'https:' ? 'https://a248.e.akamai.net/appnexus.download.akamai.com/89298/adnexus-prod/blank.js' : 'http://cdn.adnxs.com/blank.js') + '?' + Math.random();
	}

	function callMtj(params) {
		try {
			if (!window.opera) {
				writeMtjIframe(params);
			}
		} catch (err) {
			logError(err.message);
		}
	}

	// Returns a set of parameters that are used in the mtjparams0...x 
	// parameters passed to mtj for each individual placement
	function getMtjTagParams(params) {
		var output = "";
		for (var i in params) {
			if (adnxs.megatag.hasOwnProperty(params, i)) {
				switch (i) {
					case 'placementCount':
					case 'setDomain':
					case 'frameHelper':
					case 'setIframeSize':
					case 'adnxsId':
					case 'frameWindow':
					case 'adnxsMember':
					case 'elementId':
					case 'targetId':
					case 'debug':
					case 'mtjUri':
					case 'rawSizes':
					case 'pubclick': // not included in mtjparams
					case 'referrer': // not included in mtjparams
					case 'age':
					case 'gender':
					case 'use_cookies':
					case 'suppressBaseTag':
					case 'placementTimeout':
					case 'subscriptions':
					case 'mtjCalled':
						break;
					case 'promoSizes':
					case 'promo_sizes':
						var lowerCaseParams = [];
						for (var j=0; j < params[i].length; j++) {
							lowerCaseParams.push(params[i][j].toLowerCase());
						}
						output += i + "=" + lowerCaseParams + '&';
						break;
					case 'size':
						output += i + "=" + params[i].toLowerCase() + "&";
						break;
					case 'adnxsCode':
						output += 'inv_code' + "=" + params[i] + "&";
						break;
					default:
						output += i + "=" + params[i] + "&";
						break;
				}
			}
		}
		output = output.substring(0, output.length-1);

		return output;
	}

	// Parameters that are only listed once for an mtj call
	function getMtjParams(params) {
		var output = "";
		for (var i in params) {
			if (adnxs.megatag.hasOwnProperty(params, i)) {
				switch (i) {
					case 'referrer':
					case 'age':
					case 'gender':
					case 'use_cookies':
						output += i + "=" + encodeURIComponent(params[i]) + "&";
						break;
					case 'pubclick':
						output += 'pubclickenc' + '=' + encodeURIComponent(params[i]) + '&';
						break;
					case 'pubclickenc':
						output += i + '=' + params[i] + '&';
						break;
					default:
						break;
				}
			}
		}
		output = output.substring(0, output.length-1);

		return output;
	}

	function checkAdnxsCode(idParam, params) {
		var placementParam;
		if (typeof idParam === 'undefined') {
			if ((params && params.adnxsCode && params.adnxsMember) || (window.adnxsCode && window.adnxsMember)) {
				if (window.adnxsCode) {
					placementParam = 'inv_code=' + window.adnxsCode;
					placementParam += '&member=' + (params && params.adnxsMember ? params.adnxsMember : window.adnxsMember);
				} else {
					placementParam = 'member=' + (params && params.adnxsMember ? params.adnxsMember : window.adnxsMember);
				}
			} else {
				throw new Error('Neither ID nor code was defined for a placement.');
			}
		} else {
			placementParam = 'id=' + idParam;
		}
		return placementParam;
	}

	function getMtjUri(params, single) {
		var idParam = (params && params.adnxsId ? params.adnxsId : window.adnxsId),
			uri = getBaseUrl() + getMtjEndpoint() + "?",
			placementParam;

		placementParam = checkAdnxsCode(idParam, params);

		uri += placementParam;

		// Hack to enable freq capping through querystring targeting
		var possibleTargets = ['A','B','C'];
		var chosenTarget = possibleTargets[Math.floor((Math.random() * 3))];

		var i = 0;
		for (var t in adnxs.megatag.requests[idParam].tags) {
			if (adnxs.megatag.hasOwnProperty(adnxs.megatag.requests[idParam].tags, t) && (!single || single && adnxs.megatag.requests[idParam].tags[t].mtjCalled === false)) {
				adnxs.megatag.requests[idParam].tags[t].mtjCalled = true;
				var uriParams = getMtjTagParams(adnxs.megatag.requests[idParam].tags[t]);

				uriParams += '&fcp_target='+chosenTarget;

				uri += "&mtjtag" + i + "=" + t;
				uri += "&mtjparams" + i + "=" + encodeURIComponent(uriParams);
				i++;
			}
		}

		uri += "&mtjntags=" + i;

		uri += (isPageExclusive(i, params.adnxsId) ? '&exclusive=true' : '&exclusive=false');
		if (typeof adnxs.megatag.requests[params.adnxsId].placementCount !== 'undefined') {
			uri += '&placement_count=' + adnxs.megatag.requests[params.adnxsId].placementCount;
		}
		uri += '&placements_loaded=' + adnxs.megatag.requests[params.adnxsId].placementsLoaded;

		var mtjParamsExtension = getMtjParams(params);

		uri = (mtjParamsExtension.length > 0 ? uri + '&' + mtjParamsExtension : uri);

		if (window.chrome && !params.referrer) {
			uri += '&referrer=' + getTopWindowUrl();
		}

		return uri;
	}

	function populateIframes(requestId) {

		// Backwards-compatible check
		// If there's no request ID, find the first call in the requests struct that does not
		// have iframes populated and try that one.
		if (!requestId) {
			for (var r in adnxs.megatag.requests) {
				if (adnxs.megatag.hasOwnProperty(adnxs.megatag.requests), r) {
					for (var t in adnxs.megatag.requests[r].tags) {
						if (adnxs.megatag.requests[r].tags[t].iframesPopulated === false) {
							requestId = r;
							break;
						}
					}
				}
				if (requestId) {
					break;
				}
			}
		}

		if (adnxs.megatag.requests[requestId]) {
			for (var t in adnxs.megatag.requests[requestId].iframes) {
				if (adnxs.megatag.hasOwnProperty(adnxs.megatag.requests[requestId].iframes, t) && adnxs.megatag.requests[requestId].tags[t].iframesPopulated === false) {
					try {
						var frameObj = adnxs.megatag.requests[requestId].iframes[t],
							origEl;

						frameObj.placeholderEl.style.display = 'none';
						origEl = insertIframe(frameObj, t);
						normalizeDomain(frameObj.frameEl);

						if (getMegatagWindow().adnxs_ads && getMegatagWindow().adnxs_ads[t]) {
							adnxs.megatag.requests[requestId].tags[t].iframesPopulated = true;

							if (navigator.userAgent.indexOf('MSIE') !== -1) {

								// Use HTML 4 / loose doctype to prevent padding/margin issues
								// in IE with HTML5 doctype and third party mark-up
								var content = '<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">\
		 	 						<html><head>\
		 	 	 						<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">\
		 	 	 						<scr'+'ipt type="text/javascript">\
		 	 	 						try {\
		 	 	 						if (document.domain !== "'+getMegatagWindow().document.domain+'") {\
										document.domain = "'+getMegatagWindow().document.domain+'";}\
										var parent_check = window.parent.document.domain;\
										} catch (err) {document.domain = "'+getMegatagWindow().document.domain+'";}\
										try {\
		 	 	 						inDapIF = true;\
		 	 	 						var adnxs = {richmedia: {}};\
		 	 	 						window.frameId = "'+t+'";\
		 	 	 						adnxs.richmedia.setSize = function(width, height) {\
		 	 		 					var iframe = window.parent.document.getElementById(window.frameId);\
		 	 		 						if (!iframe || iframe === false) { return false; }\
		 	 		 						iframe.width = width;\
		 	 		 						iframe.height = height;\
		 	 		 						iframe.style.width = width+"px";\
		 	 		 						iframe.style.height = height+"px";\
		 	 			 				};\
		 	 			 				} catch (err) {}</scr'+'ipt>\
		 	 			 				</head><body><scr'+'ipt type="text/javascript" src="'+decodeURIComponent(getMegatagWindow().adnxs_ads[t])+'"></scr'+'ipt>';

								content += '</body></html>';


								frameObj.frameEl.contentWindow.contents = content;
								frameObj.frameEl.src = 'about:blank';
								frameObj.frameEl.src = 'javascript:window["contents"];';

							} else {
								var content = '<!DOCTYPE html><html><head>\
		 	 	 						<meta charset="utf-8">\
		 	 	 						<scr'+'ipt type="text/javascript">inDapIF = true; var adnxs = {richmedia: {}}; window.frameId = "'+t+'";adnxs.richmedia.setSize = function(width, height) {\v\
		 	 	 						var iframe = window.parent.document.getElementById(window.frameId);\
		 	 		 						if (!iframe || iframe === false) { return false; }\
		 	 		 						iframe.width = width;\
		 	 		 						iframe.height = height;\
		 	 		 						iframe.style.width = width+"px";\
											iframe.style.height = height+"px";\
										};</scr'+'ipt>\
										</head><body><scr'+'ipt type="text/javascript" src="'+getBlankUrl()+'"></scr'+'ipt>\
										<scr'+'ipt type="text/javascript" src="'+decodeURIComponent(getMegatagWindow().adnxs_ads[t])+'"></scr'+'ipt>';

								content += '</body></html>';


								var cDoc = frameObj.frameEl.contentWindow.document ? frameObj.frameEl.contentWindow.document : frameObj.frameEl.document;
								cDoc.open('text/html', 'replace');
								cDoc.write(content);
								cDoc.close();

							}



						}

						frameObj.frameEl.parentNode.style.display = '';
						frameObj.frameEl.style.display = '';
						frameObj.frameEl.style.visibility = 'visible';
					} catch (err) {
						handlePopulationError(err, frameObj, requestId, t);
					}

				}
			}
			replaceBaseTags(requestId, adnxs.megatag.requests[requestId].suppressBaseTag);
		}
	}

	function handlePopulationError(err, frameObj, requestId, tagId) {
		var caseInsensitiveMessage = err.message.toLowerCase();
		if (caseInsensitiveMessage.indexOf('permission denied') > -1
			|| caseInsensitiveMessage.indexOf('access is denied') > -1) {
			logError('Access denied to placement iframe window, making tt call', 'WARN');

			var iframe = document.createElement('iframe');
			iframe.width = frameObj.params.rawSizes[0];
			iframe.height = frameObj.params.rawSizes[1];
			iframe.src = getTtUri(frameObj.params);
			iframe.frameBorder = "0";
			iframe.marginWidth = "0";
			iframe.marginHeight = "0";
			iframe.scrolling="no";
			iframe.setAttribute('border', '0');
			iframe.setAttribute('allowtransparency', "true");
			iframe.style.display = 'none';
			iframe.style.visibility = 'hidden';

			frameObj.divEl.appendChild(iframe);
			frameObj.frameEl.style.display = 'none';
			frameObj.divEl.style.display = '';
			iframe.style.display = '';
			iframe.style.visibility = '';

		} else {
			logError(err);
			throw err;
		}
	}

	function isPageExclusive(count, requestId) {
		return (typeof adnxs.megatag.requests[requestId].placementCount !== 'undefined' && 1*adnxs.megatag.placementCount === count);
	}

	function setOnload(params) {

		var callMtjWrapper = function() {
			callMtj(params);
		};

		if (ready() || (getDomReadyConfig() && domReady())) { // window load or document ready (if used) has already fired
			if (adnxs.megatag.postOnloadTimer) {clearTimeout(adnxs.megatag.postOnloadTimer);}

			// Bake in a delay to the mtj call to allow other tags to load
			adnxs.megatag.postOnloadTimer = setTimeout(function() {
				callMtj(params);
			}, 1500);

		} else { // assign callback to window load or document ready
			if (params.placementTimeout) {
				if (adnxs.megatag.preOnloadTimer) {clearTimeout(adnxs.megatag.preOnloadTimer);}
				adnxs.megatag.preOnloadTimer = setTimeout(callMtjWrapper, params.placementTimeout);
			}

			if (getMegatagWindow().addEventListener) {
				if (getDomReadyConfig()) {
					getMegatagWindow().document.addEventListener('DOMContentLoaded', callMtjWrapper, false);
				} else {
					getMegatagWindow().addEventListener('load', callMtjWrapper, false);
				}
				adnxs.megatag.requests[params.adnxsId].isOnloadSet = true;
			} else if (getMegatagWindow().attachEvent) {
				if (getDomReadyConfig()) {
					getMegatagWindow().document.attachEvent("onreadystatechange", function() {
						if (domReady()) {
							callMtjWrapper();
						}
					});
				} else {
					getMegatagWindow().attachEvent('onload', callMtjWrapper);
				}
				adnxs.megatag.requests[params.adnxsId].isOnloadSet = true;
			}
		}

	}

	function ready() { // determines whether the publisher window has already loaded by the time our call is invoked
		var s = getMegatagWindow().document.readyState;

		if (s === 'complete') {
			return true;
		} else if (typeof s === 'undefined') {
			try {
				getMegatagWindow().document.documentElement.doScroll('left');
				return true;
			} catch (e) {
				return false;
			}
		} else { // document.readyState is interactive or some other state than complete
			return false;
		}
	}

	function domReady() {
		var s = getMegatagWindow().document.readyState;
		return s === 'interactive' || s === 'loaded' || s === 'complete';
	}

	function isAutoLoad() {
		return (typeof adnxs.megatag.manualLoad === 'undefined' || adnxs.megatag.manualLoad === false);
	}

	function cleanUpCmds() {
		if (adnxs.megatag.isCleanupSet === false) {
			adnxs.megatag.isCleanupSet = true;
			if (getMegatagWindow().attachEvent) {
				getMegatagWindow().attachEvent('onload', _processQueue);
			} else if (getMegatagWindow().addEventListener) {
				getMegatagWindow().addEventListener('onload', _processQueue, false);
			}
		}
	}

	function hasConsoleLogger() {
		return (((adnxs.megatag.debug === true)
			|| (typeof adnxsDebug === 'undefined' || (typeof adnxsDebug !== 'undefined' && adnxsDebug !== false)))
			&& (window.console && window.console.log));
	}

	function logError(msg, code) {
		var errCode = code || 'GENERAL_ERROR';
		adnxs.megatag.errors.push({msg: msg, code: errCode});

		if (hasConsoleLogger()) {
			console.log(errCode + ': '+msg);
		}
	}

	function checkCount(params) {
		if (adnxs.megatag.placementCount && params.placementCount && adnxs.megatag.placementCount !== params.placementCount) {
			logError('A placement count of '+params.placementCount
				+ ' has been provided, but a placement count of '
				+ adnxs.megatag.placementCount+' was already registered. '
				+ 'The count of '+adnxs.megatag.placementCount+' will be used.'
			);
		}
	}

	function checkTags(params) {
		checkTag('adnxsFrameHelper', 'frameHelper', params);
		checkTag('adnxsPlacementCount', 'placementCount', params);
		checkTag('adnxsSetDomain', 'setDomain', params);
		checkTag('adnxsId', 'adnxsId', params);
		checkTag('adnxsCode', 'adnxsCode', params);
		checkTag('adnxsMember', 'adnxsMember', params);
		checkTag('adnxsSetIframeSize', 'setIframeSize', params);
	}

	function checkTag(globalVar, paramVar, params) {
		if ((typeof window[globalVar] !== 'undefined' && typeof params[paramVar] !== 'undefined') &&
			(window[globalVar] !== params[paramVar])) {

			logError('The variable '+globalVar+' was already set to '+window[globalVar]+' and a placement tried to override it with '+params[paramVar]);
		}
	}

	function getTtUri(params) {
		var	uri = getBaseUrl() + getTtEndpoint() + "?";

		var idParam = (params && params.adnxsId ? params.adnxsId : window.adnxsId),
			placementParam;

		placementParam = checkAdnxsCode(idParam, params);

		if ((params && params.adnxsId) || window.adnxsId) {
			uri += 'id=' + (params && params.adnxsId ? params.adnxsId : window.adnxsId);
		} else if ((params && params.adnxsCode && params.adnxsMember) || (window.adnxsCode && window.adnxsMember)) {
			uri += 'inv_code=' + (params && params.adnxsCode ? params.adnxsCode : window.adnxsCode);
			uri += '&member=' + (params && params.adnxsMember ? params.adnxsMember : window.adnxsMember);
		}

		uri += '&'+getMtjTagParams(params);

		return uri;
	}

	function normalizeDomain(iframe) {
		if (iframe.contentWindow) {
			try {
				var documentCheck = iframe.contentWindow.document.a;
			} catch (e) {
				iframe.src = 'javascript:(function(){document.open(); document.domain = "'+getMegatagWindow().document.domain+'";document.close();})();';
			}
		}
	}

	function writeTtIframe(params) {
		var src = getTtUri(params),
			scripts = (params.frameWindow || global.window).document.getElementsByTagName('script'),
			thisScript = scripts[scripts.length-1],
			iframe = (params.frameWindow || global.window).document.createElement('iframe'),
			randomizer = Math.random() * 1000,
			div = (params.frameWindow || global.window).document.createElement('div');

		var el = (params && params.targetId && getMegatagWindow().document.getElementById(params.targetId))
					? getMegatagWindow().document.getElementById(params.targetId) : thisScript;

		params.rawSizes = params.size.toLowerCase().split('x');
		iframe.id = 'tt_' + randomizer;
		iframe.name = 'tt_' + randomizer;
		iframe.width = params.rawSizes[0];
		iframe.height = params.rawSizes[1];
		iframe.frameBorder = "0";
		iframe.marginWidth = "0";
		iframe.marginHeight = "0";
		iframe.scrolling="no";
		iframe.setAttribute('border', '0');
		iframe.setAttribute('allowtransparency', "true");
		iframe.style.display = 'none';
		iframe.style.visibility = 'hidden';
		iframe.style.display = "none";
		div.style.display = 'none';

		if (thisScript) {
			try {
				div.appendChild(iframe);
				el.parentNode.insertBefore(div, el);
				iframe.src = src;
				iframe.style.display = '';
				iframe.style.visibility = 'visible';
				div.style.display = '';
			} catch (err) {
				logError(err.message);
			}
		}
		return el;

	}

	function replaceBaseTags(requestId, suppressFlag) {
		if (adnxs.megatag.requests[requestId].discoveredBaseTags && (suppressFlag && suppressFlag === true)) {
			var baseTags = adnxs.megatag.requests[requestId].discoveredBaseTags;
			logError(baseTags.length + ' <base> tag(s) were added back to the <head> element of the publisher page.', 'WARNING');
			for (var i=0; i < baseTags.length; i++) {
				getMegatagWindow().document.getElementsByTagName('head')[0].appendChild(baseTags[i]);
			}
		}
	}

	_processQueue();

}(this));
