function FlashObject(swfFile, id, dim, transparent, clsid, flashversion, element)
{
	var content = '';
	content = content +'<OBJECT classid="'+clsid+'" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version='+flashversion+',0,0,0" ID="'+id+'" '+dim+' ALIGN="">';
	content = content +'<PARAM NAME=movie VALUE="'+swfFile+'"><PARAM NAME=quality VALUE=high><PARAM NAME="wmode" VALUE="'+transparent+'"><PARAM NAME="allowscriptaccess" VALUE="always">'; 
	content = content + '<EMBED src="'+swfFile+'" quality=high wmode='+transparent+' swLiveConnect=FALSE '+dim+' NAME="'+id+'" ALIGN="" TYPE="application/x-shockwave-flash" PLUGINSPAGE="http://www.macromedia.com/go/getflashplayer">';
	content =content +'</EMBED></OBJECT>';
	document.getElementById(element).innerHTML=content;
}
